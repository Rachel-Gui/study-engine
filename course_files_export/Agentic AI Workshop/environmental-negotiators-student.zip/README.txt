Environmental Negotiators Workshop
===================================

Open the negotiators/ folder and start with:

  SETUP.pdf  - printable guide (if included)
  SETUP.md   - same content in markdown

The guide has everything: requirements, installation, and the full workshop exercise.
