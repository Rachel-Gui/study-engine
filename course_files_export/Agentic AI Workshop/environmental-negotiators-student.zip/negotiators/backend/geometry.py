"""
geometry.py — building metrics from slider values and OBJ files.
"""

import math
import numpy as np


# ---------------------------------------------------------------------------
# Slider-based computation
# ---------------------------------------------------------------------------

def _orient_facades(front_area, back_area, side_area, orientation):
    """
    Map front/back/left/right wall areas to cardinal directions.

    orientation = compass heading the front facade faces.
      0  = front faces N
      90 = front faces E
      180 = front faces S
      270 = front faces W

    L dimension is the width of the front/back facade (longer span east-west
    when facing south), W dimension is the depth (shorter side walls).
    """
    dirs = ["N", "E", "S", "W"]
    idx = round(orientation / 90) % 4
    front_dir = dirs[idx]
    back_dir = dirs[(idx + 2) % 4]
    right_dir = dirs[(idx + 1) % 4]
    left_dir = dirs[(idx + 3) % 4]

    return {
        front_dir: front_area,
        back_dir: back_area,
        right_dir: side_area,
        left_dir: side_area,
    }


def compute_geometry(L, W, H, floors, wwr, orientation):
    """
    Compute building metrics from slider-defined box dimensions.

    Parameters
    ----------
    L : float   Length (east-west span when facing south), metres
    W : float   Width/depth (north-south span when facing south), metres
    H : float   Total building height, metres
    floors : int  Number of storeys
    wwr : float   Window-to-wall ratio (0-1)
    orientation : float  Compass heading of the front facade, degrees

    Returns
    -------
    dict matching the geometry packet schema
    """
    # Core metrics
    front_back_area = L * H      # front and back walls
    side_area = W * H            # each side wall
    roof_area = L * W
    floor_area = L * W * floors
    volume = L * W * H

    total_wall = 2 * front_back_area + 2 * side_area
    envelope = total_wall + roof_area   # floor excluded from thermal envelope

    sv_ratio = round(envelope / volume, 2)
    form_factor = round(envelope / floor_area, 2)

    facade_areas = _orient_facades(front_back_area, front_back_area, side_area, orientation)

    south_wall = facade_areas.get("S", 0)
    south_bias = round(south_wall / total_wall, 2)

    narrative = (
        f"Building: {L}m × {W}m footprint, {H}m tall, {floors} floor(s). "
        f"Volume: {volume} m³. Roof area: {roof_area} m². "
        f"Floor area: {floor_area} m² (all floors). "
        f"S/V ratio: {sv_ratio}, form factor: {form_factor}. "
        f"South wall area: {south_wall} m² ({int(south_bias * 100)}% of total wall). "
        f"WWR: {wwr}, orientation: {orientation}°."
    )

    return {
        "source": "sliders",
        "dims": {"L": L, "W": W, "H": H, "floors": floors},
        "volume": volume,
        "roof_area": roof_area,
        "floor_area": floor_area,
        "facade_areas": facade_areas,
        "sv_ratio": sv_ratio,
        "form_factor": form_factor,
        "south_bias": south_bias,
        "wwr": wwr,
        "orientation": orientation,
        "narrative": narrative,
    }


# ---------------------------------------------------------------------------
# OBJ parser
# ---------------------------------------------------------------------------

def _triangle_normal_and_area(v0, v1, v2):
    """Return (unit_normal, area) for a triangle defined by three 3-D points."""
    a = v1 - v0
    b = v2 - v0
    cross = np.cross(a, b)
    norm = np.linalg.norm(cross)
    if norm < 1e-10:
        return np.array([0.0, 0.0, 0.0]), 0.0
    return cross / norm, norm / 2.0


def _compass_bucket(normal):
    """
    Map a wall-face normal to one of N/E/S/W using atan2.

    OBJ uses Y-up convention.
    atan2(-normal[2], normal[0]) gives angle from +X axis toward -Z.
    """
    angle_rad = math.atan2(-normal[2], normal[0])
    angle_deg = math.degrees(angle_rad) % 360  # 0-360

    # Bucket: E=0±45, N=90±45, W=180±45, S=270±45
    # But we want compass: N=north (+Z in world), S=south (-Z), E=east (+X), W=west (-X)
    # In OBJ Y-up: +X = East, -X = West, +Z = toward viewer (South in plan view), -Z = North
    # atan2(-normal[2], normal[0]):
    #   normal pointing +X (East)  -> atan2(0, 1)  =   0°
    #   normal pointing +Z (South) -> atan2(-1, 0) = -90° -> 270°
    #   normal pointing -X (West)  -> atan2(0,-1)  = 180°
    #   normal pointing -Z (North) -> atan2(1, 0)  =  90°
    # Buckets (centre -> label):
    #   315-45   -> E
    #   45-135   -> N
    #   135-225  -> W
    #   225-315  -> S
    if angle_deg < 45 or angle_deg >= 315:
        return "E"
    elif angle_deg < 135:
        return "N"
    elif angle_deg < 225:
        return "W"
    else:
        return "S"


def parse_obj(obj_text: str) -> dict:
    """
    Parse a Wavefront OBJ string and compute building metrics.

    Parameters
    ----------
    obj_text : str  Contents of a .obj file

    Returns
    -------
    dict matching the geometry packet schema (source="obj")
    """
    vertices = []
    face_indices = []  # list of tuples of 0-based vertex indices (triangles)

    for line in obj_text.splitlines():
        line = line.strip()
        if line.startswith("v "):
            parts = line.split()
            vertices.append([float(parts[1]), float(parts[2]), float(parts[3])])
        elif line.startswith("f "):
            parts = line.split()[1:]
            # Each part may be "v", "v/vt", or "v/vt/vn" — take the first index
            idx = [int(p.split("/")[0]) - 1 for p in parts]  # convert to 0-based
            if len(idx) == 3:
                face_indices.append(tuple(idx))
            elif len(idx) == 4:
                # Triangulate quad
                face_indices.append((idx[0], idx[1], idx[2]))
                face_indices.append((idx[0], idx[2], idx[3]))
            # Ignore n-gons beyond quads (rare in architectural OBJ)

    verts = np.array(vertices, dtype=float)

    # Bounding box for dims
    bb_min = verts.min(axis=0)
    bb_max = verts.max(axis=0)
    bb_size = bb_max - bb_min  # [dx, dy, dz] in OBJ Y-up: X=E, Y=up, Z=S

    height = float(bb_size[1])
    estimated_floors = max(1, round(height / 3.5))

    # Classify each face and accumulate areas + volume
    facade_areas = {"N": 0.0, "S": 0.0, "E": 0.0, "W": 0.0}
    roof_area = 0.0
    floor_area_geom = 0.0
    signed_volume = 0.0

    for tri in face_indices:
        v0, v1, v2 = verts[tri[0]], verts[tri[1]], verts[tri[2]]
        normal, area = _triangle_normal_and_area(v0, v1, v2)

        # Volume contribution (divergence theorem, signed)
        cross = np.cross(v1 - v0, v2 - v0)
        signed_volume += np.dot(v0, cross)

        # Classify by Y-component of normal
        ny = normal[1]
        if ny > 0.7:
            roof_area += area
        elif ny < -0.7:
            floor_area_geom += area
        else:
            direction = _compass_bucket(normal)
            facade_areas[direction] += area

    volume = abs(signed_volume) / 6.0

    total_wall = sum(facade_areas.values())
    envelope = total_wall + roof_area

    sv_ratio = round(envelope / volume, 2) if volume > 0 else 0.0
    functional_floor_area = roof_area * estimated_floors  # proxy using footprint
    form_factor = round(envelope / functional_floor_area, 2) if functional_floor_area > 0 else 0.0

    south_wall = facade_areas.get("S", 0.0)
    south_bias = round(south_wall / total_wall, 2) if total_wall > 0 else 0.0

    # Round facade areas for cleanliness
    facade_areas_rounded = {k: round(v, 2) for k, v in facade_areas.items()}

    narrative = (
        f"OBJ geometry: bounding box {round(bb_size[0], 1)}m × {round(bb_size[2], 1)}m footprint, "
        f"{round(height, 1)}m tall (~{estimated_floors} floor(s)). "
        f"Volume: {round(volume, 1)} m³. Roof area: {round(roof_area, 1)} m². "
        f"S/V ratio: {sv_ratio}. "
        f"South wall: {round(south_wall, 1)} m² ({int(south_bias * 100)}% of total wall)."
    )

    return {
        "source": "obj",
        "dims": {
            "L": round(float(bb_size[0]), 2),
            "W": round(float(bb_size[2]), 2),
            "H": round(height, 2),
            "floors": estimated_floors,
        },
        "volume": round(volume, 2),
        "roof_area": round(roof_area, 2),
        "floor_area": round(functional_floor_area, 2),
        "facade_areas": facade_areas_rounded,
        "sv_ratio": sv_ratio,
        "form_factor": form_factor,
        "south_bias": south_bias,
        "wwr": 0.4,
        "orientation": 180,
        "narrative": narrative,
        "vertices": verts.tolist(),
        "faces": list(face_indices),
    }
