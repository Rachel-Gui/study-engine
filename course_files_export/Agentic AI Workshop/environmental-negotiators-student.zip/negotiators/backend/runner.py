import json
import os
import re

import ollama

from agents import Agent

MODEL = os.environ.get("OLLAMA_MODEL", "glm-5.1:cloud")

_async_client = ollama.AsyncClient()

# ---------------------------------------------------------------------------
# Output schemas appended to agent system instructions
# ---------------------------------------------------------------------------

ADVOCATE_OUTPUT_SCHEMA = """

Cite specific standards, codes, or data sources to support your claims (e.g. "per ASHRAE 90.1-2019", "NECB 2020 Table 3.2.1.2", "IESO 2023 grid data"). Every numeric claim must have a source.

Respond ONLY with valid JSON matching this schema exactly:
{
  "argument": "<your main argument — cite sources for every numeric claim>",
  "critical_finding": "<the single most important finding with source citation>",
  "proposed_changes": "<specific changes you recommend with code/standard references>",
  "geometry_suggestion": "<any specific geometry modifications you suggest>",
  "sources": ["<list of standards, codes, and data sources you referenced>"]
}"""

MANAGER_OUTPUT_SCHEMA = """

Cite specific standards or data when resolving conflicts. Reference the sources advocates provided.

Respond ONLY with valid JSON matching this schema exactly:
{
  "agreements": ["<list of points all advocates agree on>"],
  "conflicts": [{"issue": "<what they disagreed about>", "positions": {"<advocate>": "<their stance>"}, "resolution": "<your decision and why>"}],
  "final_verdict": "<your synthesis and recommended direction>",
  "suggested_geometry": {"L": 0, "W": 0, "H": 0, "floors": 0, "wwr": 0.0, "orientation": 0},
  "constraint_packet": {"<metric>": 0.0},
  "sources": ["<key sources referenced across the arbitration>"]
}"""

SITE_RESEARCH_SCHEMA = """

Cite specific data sources for every claim (e.g. "Environment Canada Climate Normals 1991-2020", "IESO Annual Planning Outlook 2023", "Ontario Building Code SB-10"). Do not make up data.

Respond ONLY with valid JSON matching this schema exactly:
{
  "site": "<location and site description>",
  "program": "<building program and use>",
  "climate_zone": "<ASHRAE or local climate zone with source>",
  "dominant_driver": "<the dominant climate driver for this location>",
  "design_temps": "<heating and cooling design temperatures with source>",
  "grid_carbon_intensity": "<grid carbon intensity in kg CO2e/kWh with source>",
  "grid_renewable_pct": "<percentage of renewables on the grid with source>",
  "energy_code": "<applicable energy code with version/year>",
  "hazards": "<relevant climate or natural hazards with source>",
  "narrative": "<2-3 sentence summary of the key design implications>",
  "sources": ["<list every standard, dataset, and code you referenced — e.g. 'ASHRAE Fundamentals 2021', 'IESO Annual Planning Outlook 2023'>"]
}"""

_SCHEMAS = {
    "advocate": ADVOCATE_OUTPUT_SCHEMA,
    "manager": MANAGER_OUTPUT_SCHEMA,
    "site_research": SITE_RESEARCH_SCHEMA,
}


# ---------------------------------------------------------------------------
# Prompt builder
# ---------------------------------------------------------------------------

def build_prompt(agent: Agent, context: dict, agent_type: str = "advocate") -> dict:
    """Build the system/user prompt dict for a given agent and context."""
    schema = _SCHEMAS.get(agent_type, ADVOCATE_OUTPUT_SCHEMA)
    system = agent.instructions + schema

    geometry = context.get("geometry", {})
    climate = context.get("climate", {})

    geo_narrative = geometry.get("narrative", "")
    climate_narrative = climate.get("narrative", "")

    # Serialize remaining geometry/climate data (excluding the narrative key)
    geo_data = {k: v for k, v in geometry.items() if k != "narrative"}
    climate_data = {k: v for k, v in climate.items() if k != "narrative"}

    user_parts = []

    user_parts.append(f"## Geometry\n{geo_narrative}")
    if geo_data:
        user_parts.append(f"```json\n{json.dumps(geo_data, indent=2)}\n```")

    # If geometry is from an OBJ upload, tell agents about the complex form
    if geometry.get("source") == "obj":
        user_parts.append(
            "**Important:** This geometry was uploaded as a 3D mesh (OBJ file) with a complex "
            "massing form — it is NOT a simple rectangular box. The L, W, H dimensions represent "
            "the bounding box of the actual mesh. Any suggested geometry modifications (L, W, H "
            "changes) will be applied as proportional scaling to the existing mesh form. "
            "Do NOT recommend simplifying the massing into a basic rectangle. "
            "Preserve the character of the existing massing in your recommendations."
        )

    user_parts.append(f"## Climate\n{climate_narrative}")
    if climate_data:
        user_parts.append(f"```json\n{json.dumps(climate_data, indent=2)}\n```")

    # For manager type, include advocate results and stakeholder priorities
    if agent_type == "manager":
        advocate_results = context.get("advocate_results", [])
        if advocate_results:
            user_parts.append("## Advocate Arguments")
            for result in advocate_results:
                agent_name = result.get("agent", "Unknown")
                response = result.get("response", {})
                user_parts.append(f"### {agent_name}")
                user_parts.append(json.dumps(response, indent=2))

        # Include stakeholder priority weights if provided
        priorities = context.get("priorities", {})
        if priorities:
            priority_lines = []
            for agent_name, level in priorities.items():
                priority_lines.append(f"- {agent_name}: **{level}** priority")
            user_parts.append(
                "## Stakeholder Priorities\n"
                "The design team has indicated the following priority levels:\n"
                + "\n".join(priority_lines)
                + "\n\n"
                "When advocates conflict, give more weight to higher-priority perspectives. "
                "However, a low-priority concern can still override if ignoring it would "
                "violate building codes or create severe performance failures."
            )

    user = "\n\n".join(user_parts)

    return {"system": system, "user": user}


# ---------------------------------------------------------------------------
# JSON response parser
# ---------------------------------------------------------------------------

def _parse_json_response(raw: str) -> dict:
    """Parse a JSON response from the model, with fallbacks."""
    raw = raw.strip()

    # 1. Try direct JSON parse
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        pass

    # 2. Try extracting from markdown code blocks (```json ... ``` or ``` ... ```)
    code_block_pattern = r"```(?:json)?\s*([\s\S]*?)```"
    matches = re.findall(code_block_pattern, raw)
    for match in matches:
        try:
            return json.loads(match.strip())
        except json.JSONDecodeError:
            continue

    # 3. Fallback: wrap raw text in structured dict
    return {
        "argument": raw,
        "critical_finding": "Raw response — model did not return valid JSON.",
        "proposed_changes": "See argument text above.",
        "geometry_suggestion": "",
    }


# ---------------------------------------------------------------------------
# Agent runner
# ---------------------------------------------------------------------------

async def run_agent(agent: Agent, context: dict, agent_type: str = "advocate") -> dict:
    """Call Ollama with the given agent and context, returning a structured result dict."""
    prompt = build_prompt(agent, context, agent_type=agent_type)

    messages = [
        {"role": "system", "content": prompt["system"]},
        {"role": "user", "content": prompt["user"]},
    ]

    try:
        response = await _async_client.chat(model=MODEL, messages=messages)
        raw_content = response["message"]["content"]
        parsed = _parse_json_response(raw_content)
        return {
            "agent": agent.name,
            "role": agent.role,
            "color": agent.color,
            "icon": agent.icon,
            "status": "success",
            "response": parsed,
        }
    except Exception as exc:
        return {
            "agent": agent.name,
            "role": agent.role,
            "color": agent.color,
            "icon": agent.icon,
            "status": "error",
            "response": {"error": str(exc)},
        }
