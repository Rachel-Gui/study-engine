import sys
import os
import json
import importlib
import asyncio

from fastapi import FastAPI, UploadFile, File, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, StreamingResponse

# Add parent directory to path so we can import agents.py and negotiators.py
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from agents import Agent
from backend.runner import run_agent
from backend.pipeline import run_pipeline
from backend.geometry import compute_geometry, parse_obj

app = FastAPI(title="Environmental Negotiators")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _load_negotiators():
    """Import negotiators.py from project root, reloading each time to pick up student changes.

    Returns (site_researcher, advocates, manager).
    Raises ImportError if the module is missing or agents are not defined.
    """
    # Ensure the project root is on sys.path
    project_root = os.path.dirname(os.path.dirname(__file__))
    if project_root not in sys.path:
        sys.path.insert(0, project_root)

    # Force reload so live student edits are reflected
    if "negotiators" in sys.modules:
        mod = importlib.reload(sys.modules["negotiators"])
    else:
        import importlib as _il
        mod = _il.import_module("negotiators")

    site_researcher = getattr(mod, "site_researcher", None)
    advocates = getattr(mod, "advocates", None)
    manager = getattr(mod, "manager", None)

    return site_researcher, advocates, manager


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------

@app.get("/api/agents")
async def get_agents():
    """Return all agents defined in negotiators.py as a list of dicts."""
    try:
        site_researcher, advocates, manager = _load_negotiators()
    except Exception as exc:
        return {"error": str(exc)}

    agents = []

    if site_researcher is not None:
        d = site_researcher.to_dict()
        d["type"] = "site_research"
        agents.append(d)

    if advocates:
        for adv in advocates:
            d = adv.to_dict()
            d["type"] = "advocate"
            agents.append(d)

    if manager is not None:
        d = manager.to_dict()
        d["type"] = "manager"
        agents.append(d)

    return {"agents": agents}


@app.post("/api/test-agent")
async def test_agent(body: dict):
    """Run a single agent and return its result.

    Expected body: { agent_name, geometry, site, program }
    """
    agent_name = body.get("agent_name", "")
    geometry = body.get("geometry", {})
    site = body.get("site", "")
    program = body.get("program", "")

    try:
        site_researcher, advocates, manager = _load_negotiators()
    except Exception as exc:
        return {"error": str(exc)}

    # Build flat list of (agent, type) pairs to search
    all_agents = []
    if site_researcher is not None:
        all_agents.append((site_researcher, "site_research"))
    if advocates:
        for adv in advocates:
            all_agents.append((adv, "advocate"))
    if manager is not None:
        all_agents.append((manager, "manager"))

    # Find the requested agent
    match = None
    for agent, agent_type in all_agents:
        if agent.name == agent_name:
            match = (agent, agent_type)
            break

    if match is None:
        return {"error": f"Agent '{agent_name}' not found"}

    agent, agent_type = match

    # Build context
    if agent_type == "site_research":
        context = {
            "geometry": geometry,
            "climate": {
                "narrative": (
                    f"Research the site at {site} for a {program} building. "
                    "Identify the climate zone, dominant drivers, design temperatures, "
                    "grid carbon intensity, applicable energy code, and key hazards."
                )
            },
        }
    elif agent_type == "manager":
        # Provide placeholder advocate results for manager test
        context = {
            "geometry": geometry,
            "climate": {"narrative": f"Site: {site}. Program: {program}."},
            "advocate_results": [
                {
                    "agent": "Placeholder Advocate",
                    "role": "Test advocate",
                    "response": {
                        "argument": "This is a placeholder argument for manager testing.",
                        "critical_finding": "No real advocates have run yet.",
                        "proposed_changes": "None — this is a test.",
                        "geometry_suggestion": "No suggestion.",
                    },
                }
            ],
        }
    else:
        context = {
            "geometry": geometry,
            "climate": {"narrative": f"Site: {site}. Program: {program}."},
        }

    result = await run_agent(agent, context, agent_type=agent_type)
    return result


@app.post("/api/analyze")
async def analyze(body: dict):
    """Run the full negotiation pipeline and stream results as SSE."""
    geometry = body.get("geometry", {})
    site = body.get("site", "")
    program = body.get("program", "")

    try:
        site_researcher, advocates, manager = _load_negotiators()
    except Exception as exc:
        return JSONResponse(
            status_code=422,
            content={"error": f"Could not load negotiators.py: {exc}"},
        )

    if site_researcher is None or not advocates or manager is None:
        return JSONResponse(
            status_code=422,
            content={
                "error": (
                    "negotiators.py must define site_researcher, advocates (list), "
                    "and manager before running the pipeline."
                )
            },
        )

    quick = body.get("quick", False)
    priorities = body.get("priorities", {})

    async def event_stream():
        async for event in run_pipeline(
            site_researcher=site_researcher,
            advocates=advocates,
            manager=manager,
            geometry=geometry,
            site=site,
            program=program,
            quick=quick,
            priorities=priorities,
        ):
            event_type = event.get("event", "message")
            data = json.dumps(event.get("data", {}))
            yield f"event: {event_type}\ndata: {data}\n\n"

    return StreamingResponse(event_stream(), media_type="text/event-stream")


@app.post("/api/upload-obj")
async def upload_obj(file: UploadFile = File(...)):
    """Accept an OBJ file upload and return computed geometry metrics."""
    contents = await file.read()
    obj_text = contents.decode("utf-8", errors="replace")

    try:
        geometry = parse_obj(obj_text)
    except ValueError as exc:
        return {"error": str(exc)}

    return geometry


@app.post("/api/geometry")
async def geometry_from_sliders(body: dict):
    """Compute geometry metrics from slider values.

    Expected body: { L, W, H, floors, wwr, orientation }
    """
    L = body.get("L", 20.0)
    W = body.get("W", 15.0)
    H = body.get("H", 10.0)
    floors = body.get("floors", 3)
    wwr = body.get("wwr", 0.4)
    orientation = body.get("orientation", 180.0)

    result = compute_geometry(
        L=float(L),
        W=float(W),
        H=float(H),
        floors=int(floors),
        wwr=float(wwr),
        orientation=float(orientation),
    )
    return result
