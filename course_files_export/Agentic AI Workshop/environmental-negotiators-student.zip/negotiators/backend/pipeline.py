import asyncio
from typing import AsyncGenerator

from agents import Agent
from backend.runner import run_agent


# ---------------------------------------------------------------------------
# Quick-mode site data lookup — keyed by region keywords in the address
# ---------------------------------------------------------------------------

_SITE_DATA = [
    {
        "keywords": ["waterloo", "kitchener", "ontario", "toronto", "ottawa", "hamilton"],
        "climate_zone": "ASHRAE 6A (cold-humid)",
        "dominant_driver": "Heating-dominated — ~4,400 HDD, ~350 CDD (ASHRAE Fundamentals)",
        "design_temps": "Winter: -22°C (99% heating), Summer: 32°C (1% cooling) — ASHRAE 2021",
        "grid_carbon_intensity": "~0.03 kg CO₂e/kWh — Ontario grid is 90%+ nuclear/hydro (IESO 2023)",
        "grid_renewable_pct": "~94% non-emitting (nuclear 58%, hydro 26%, wind/solar 10%)",
        "energy_code": "Ontario Building Code SB-10 (based on NECB 2017) / ASHRAE 90.1-2019",
        "hazards": "Freeze-thaw cycling, ice storms, increasing extreme heat events, Great Lakes flooding",
        "narrative": (
            "Southern Ontario is a heating-dominated climate (ASHRAE 6A) where envelope thermal "
            "performance is critical. The grid is very low-carbon due to nuclear/hydro dominance, "
            "so embodied carbon in envelope materials is the bigger lever. "
            "Design should prioritise thermal mass, minimise east/west glazing to reduce summer "
            "overheating risk, and maximise south-facing glazing for passive solar gain."
        ),
        "sources": [
            "ASHRAE Fundamentals 2021 — Climate Design Data",
            "IESO Annual Planning Outlook 2023 — Ontario Grid Mix",
            "Ontario Building Code SB-10 (Supplementary Standard)",
            "NECB 2017 — National Energy Code of Canada for Buildings",
            "ASHRAE 90.1-2019 — Energy Standard for Buildings",
            "Environment and Climate Change Canada — Climate Normals 1991–2020",
        ],
    },
    {
        "keywords": ["seattle", "washington", "portland", "oregon", "vancouver bc"],
        "climate_zone": "ASHRAE 4C (mixed-marine)",
        "dominant_driver": "Heating-dominated with mild summers — ~4,800 HDD, ~150 CDD",
        "design_temps": "Winter: -3°C (99% heating), Summer: 31°C (1% cooling) — ASHRAE 2021",
        "grid_carbon_intensity": "~0.08 kg CO₂e/kWh — WA grid is 75%+ hydro (EIA 2023)",
        "grid_renewable_pct": "~80% renewable (hydro 68%, wind 8%, solar 4%)",
        "energy_code": "Washington State Energy Code 2021 (C406 stretch) / ASHRAE 90.1-2019",
        "hazards": "Seismic (Cascadia subduction zone), atmospheric rivers/flooding, wildfire smoke, landslides",
        "narrative": (
            "Pacific Northwest is mild but heating-dominated (4C), with a very low-carbon hydro grid. "
            "Embodied carbon dominates lifecycle emissions — compact geometry wins. "
            "Daylighting is critical due to overcast winters. South and east glazing helps; "
            "glare is rarely an issue. Seismic design and wildfire smoke infiltration are key resilience concerns."
        ),
        "sources": [
            "ASHRAE Fundamentals 2021 — Climate Design Data",
            "U.S. EIA State Electricity Profiles 2023 — Washington",
            "Washington State Energy Code 2021 (C406)",
            "ASHRAE 90.1-2019 — Energy Standard for Buildings",
            "USGS — Cascadia Subduction Zone Hazard Assessment",
        ],
    },
    {
        "keywords": ["new york", "manhattan", "brooklyn", "queens", "new jersey", "newark", "boston", "massachusetts"],
        "climate_zone": "ASHRAE 4A/5A (mixed-humid / cold-humid)",
        "dominant_driver": "Heating-dominated with significant cooling — ~4,800 HDD, ~800 CDD",
        "design_temps": "Winter: -12°C (99% heating), Summer: 34°C (1% cooling) — ASHRAE 2021",
        "grid_carbon_intensity": "~0.25 kg CO₂e/kWh — Northeast grid relies on natural gas (EIA 2023)",
        "grid_renewable_pct": "~35% (nuclear 28%, hydro/wind/solar ~7%)",
        "energy_code": "NYC Energy Conservation Code 2020 / Local Law 97 carbon caps",
        "hazards": "Coastal flooding, extreme heat, nor'easters, aging infrastructure vulnerability",
        "narrative": (
            "Northeast US has both heating and cooling demands with a carbon-heavy gas grid. "
            "Operational carbon is a major lever — passive envelope strategies and orientation matter. "
            "NYC Local Law 97 imposes strict carbon caps. Minimise east/west glazing for summer loads; "
            "south glazing with shading optimises winter gain while limiting summer overheating."
        ),
        "sources": [
            "ASHRAE Fundamentals 2021 — Climate Design Data",
            "U.S. EIA State Electricity Profiles 2023 — New York / New England",
            "NYC Energy Conservation Code 2020",
            "NYC Local Law 97 of 2019 — Building Emissions Limits",
            "FEMA Flood Insurance Rate Maps — NYC Coastal Zones",
        ],
    },
    {
        "keywords": ["london", "england", "uk", "manchester", "birmingham", "edinburgh", "scotland"],
        "climate_zone": "ASHRAE 4A / UK maritime temperate",
        "dominant_driver": "Heating-dominated — ~3,000 HDD, minimal cooling demand",
        "design_temps": "Winter: -4°C (99% heating), Summer: 28°C (1% cooling) — CIBSE Guide A",
        "grid_carbon_intensity": "~0.21 kg CO₂e/kWh — UK grid (BEIS 2023), declining rapidly",
        "grid_renewable_pct": "~45% (wind 28%, nuclear 15%, solar 4%)",
        "energy_code": "Part L Building Regulations 2021 / BREEAM",
        "hazards": "Increasing summer overheating, flooding, wind exposure",
        "narrative": (
            "UK maritime climate is heating-dominated but overheating risk is growing. "
            "Grid is decarbonising fast through offshore wind. Envelope insulation levels are high "
            "under Part L. Daylighting is crucial given low solar altitude — "
            "maximise south glazing with good solar control to avoid future overheating."
        ),
        "sources": [
            "CIBSE Guide A — Environmental Design (2015 edition)",
            "BEIS UK Government GHG Conversion Factors 2023",
            "UK Building Regulations Part L 2021",
            "BREEAM New Construction Technical Manual",
            "Met Office UK Climate Projections (UKCP18)",
        ],
    },
    {
        "keywords": ["dubai", "abu dhabi", "uae", "qatar", "doha", "riyadh", "saudi"],
        "climate_zone": "ASHRAE 0B/1B (extremely hot-dry)",
        "dominant_driver": "Cooling-dominated — ~100 HDD, ~4,000+ CDD",
        "design_temps": "Winter: 12°C, Summer: 48°C (1% cooling) — ASHRAE 2021",
        "grid_carbon_intensity": "~0.55 kg CO₂e/kWh — gas/oil dominated grid",
        "grid_renewable_pct": "~5% (solar growing rapidly)",
        "energy_code": "Estidama Pearl / ASHRAE 90.1-2019 local amendments",
        "hazards": "Extreme heat, sandstorms, humidity-corrosion, sea level rise (coastal)",
        "narrative": (
            "Gulf climate is extremely cooling-dominated. Minimise glazing on all facades, "
            "especially east/west. High S/V ratio is bad — compact forms reduce cooling load. "
            "Grid is very carbon-heavy so operational energy is the dominant carbon lever. "
            "Self-shading geometry and thermal mass are critical design strategies."
        ),
        "sources": [
            "ASHRAE Fundamentals 2021 — Climate Design Data",
            "Abu Dhabi Urban Planning Council — Estidama Pearl Rating System",
            "ASHRAE 90.1-2019 — Energy Standard for Buildings (UAE amendments)",
            "IRENA Renewable Energy Statistics 2023 — GCC Region",
        ],
    },
]

# Fallback for unrecognised locations
_DEFAULT_SITE_DATA = {
    "climate_zone": "ASHRAE 5A (estimated — cold-humid)",
    "dominant_driver": "Heating-dominated — typical mid-latitude",
    "design_temps": "Winter: ~-15°C, Summer: ~33°C (estimated)",
    "grid_carbon_intensity": "~0.30 kg CO₂e/kWh (global average estimate)",
    "grid_renewable_pct": "~30% (estimated global average)",
    "energy_code": "ASHRAE 90.1-2019 / local equivalent",
    "hazards": "Location-specific hazards unknown — run full debate for detailed research",
    "narrative": (
        "Location not recognised — using mid-latitude cold-climate defaults. "
        "Heating is likely the dominant driver. Run a full debate for site-specific data."
    ),
    "sources": [
        "ASHRAE 90.1-2019 — Energy Standard for Buildings",
        "IEA World Energy Outlook 2023 — Global Grid Averages",
    ],
}


def _lookup_site_data(site: str) -> dict:
    """Match site address to the best-fit climate data entry."""
    site_lower = site.lower()
    for entry in _SITE_DATA:
        for kw in entry["keywords"]:
            if kw in site_lower:
                return {k: v for k, v in entry.items() if k != "keywords"}
    return _DEFAULT_SITE_DATA


async def run_pipeline(
    site_researcher: Agent,
    advocates: list[Agent],
    manager: Agent,
    geometry: dict,
    site: str,
    program: str,
    quick: bool = False,
    priorities: dict | None = None,
) -> AsyncGenerator[dict, None]:
    """Run the three-phase negotiation pipeline, yielding SSE-style event dicts.

    Args:
        quick: If True, use lookup-based site data instead of running the LLM researcher.
               Saves ~60-90 seconds on local models.
        priorities: Optional dict mapping advocate name -> priority level ("High"/"Medium"/"Low").
    """

    if quick:
        # ------------------------------------------------------------------
        # Quick mode — lookup-based site-specific context (no LLM call)
        # ------------------------------------------------------------------
        yield {"event": "phase", "data": {"phase": 1, "label": "Looking up site data..."}}

        site_data = _lookup_site_data(site)

        climate_data = {
            "site": site,
            "program": program,
            **site_data,
        }

        yield {
            "event": "agent_result",
            "data": {
                "agent": "Site Researcher",
                "role": "Site-specific data (quick lookup)",
                "color": "#4A90D9",
                "icon": "globe",
                "status": "success",
                "type": "site_research",
                "response": climate_data,
            },
        }
    else:
        # ------------------------------------------------------------------
        # Phase 1 — Site Research (sequential)
        # ------------------------------------------------------------------
        yield {"event": "phase", "data": {"phase": 1, "label": "Researching site..."}}

        site_context = {
            "geometry": geometry,
            "climate": {
                "narrative": (
                    f"Research the site at {site} for a {program} building. "
                    "Identify the climate zone, dominant drivers, design temperatures, "
                    "grid carbon intensity, applicable energy code, and key hazards."
                )
            },
        }

        site_result = await run_agent(site_researcher, site_context, agent_type="site_research")
        yield {"event": "agent_result", "data": {**site_result, "type": "site_research"}}

        # Extract climate data from the site researcher's response for downstream agents
        climate_data = site_result.get("response", {})

    # ------------------------------------------------------------------
    # Phase 2 — Advocates (parallel)
    # ------------------------------------------------------------------
    yield {"event": "phase", "data": {"phase": 2, "label": "Advocates arguing..."}}

    advocate_context = {
        "geometry": geometry,
        "climate": climate_data,
    }

    # Create all tasks up front so they run concurrently
    tasks = [
        asyncio.create_task(run_agent(advocate, advocate_context, agent_type="advocate"))
        for advocate in advocates
    ]

    advocate_results = []
    for coro in asyncio.as_completed(tasks):
        result = await coro
        tagged = {**result, "type": "advocate"}
        advocate_results.append(tagged)
        yield {"event": "agent_result", "data": tagged}

    # ------------------------------------------------------------------
    # Phase 3 — Manager (sequential)
    # ------------------------------------------------------------------
    yield {"event": "phase", "data": {"phase": 3, "label": "Manager synthesising..."}}

    manager_context = {
        "geometry": geometry,
        "climate": climate_data,
        "advocate_results": advocate_results,
        "priorities": priorities or {},
    }

    manager_result = await run_agent(manager, manager_context, agent_type="manager")
    yield {"event": "agent_result", "data": {**manager_result, "type": "manager"}}

    # Build the done payload from the manager's response
    manager_response = manager_result.get("response", {})
    yield {
        "event": "done",
        "data": {
            "constraint_packet": manager_response.get("constraint_packet", ""),
            "suggested_geometry": manager_response.get("suggested_geometry", ""),
        },
    }
