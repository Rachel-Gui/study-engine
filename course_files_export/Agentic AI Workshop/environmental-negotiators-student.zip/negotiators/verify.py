#!/usr/bin/env python3
"""Pre-workshop verification script.

Checks that all required tools are installed and configured:
1. Python 3.10+
2. Python dependencies (fastapi, uvicorn, ollama)
3. Ollama running
4. glm-5.1:cloud model pulled
5. Node.js 18+
6. Frontend dependencies installed
7. Agent class importable
8. Backend reachable (if running)
"""

import os
import sys
import subprocess
import importlib

REQUIRED_MODEL = "glm-5.1:cloud"
CHECKS_PASSED = 0
CHECKS_FAILED = 0


def check(label: str, passed: bool, detail: str = ""):
    global CHECKS_PASSED, CHECKS_FAILED
    icon = "[+]" if passed else "[X]"
    msg = f"  {icon} {label}"
    if detail:
        msg += f" — {detail}"
    print(msg)
    if passed:
        CHECKS_PASSED += 1
    else:
        CHECKS_FAILED += 1


def main():
    print("\n  Environmental Negotiators — Workshop Verification\n")

    v = sys.version_info
    check(f"Python {v.major}.{v.minor}.{v.micro}", v >= (3, 10), "Need 3.10+" if v < (3, 10) else "")

    for pkg in ["fastapi", "uvicorn", "ollama"]:
        try:
            importlib.import_module(pkg)
            check(f"Python package: {pkg}", True)
        except ImportError:
            check(f"Python package: {pkg}", False, "Run: pip install -r requirements.txt")

    try:
        result = subprocess.run(["ollama", "list"], capture_output=True, text=True, timeout=5)
        ollama_running = result.returncode == 0
        check("Ollama running", ollama_running)
    except (FileNotFoundError, subprocess.TimeoutExpired):
        check("Ollama running", False, "Install from https://ollama.com and start it")
        ollama_running = False

    if ollama_running:
        # Check for the exact model name (e.g. "glm-5.1:cloud") in ollama list output
        model_found = REQUIRED_MODEL in result.stdout
        check(f"Model: {REQUIRED_MODEL}", model_found, f"Run: ollama pull {REQUIRED_MODEL}" if not model_found else "")
    else:
        check(f"Model: {REQUIRED_MODEL}", False, "Start Ollama first")

    try:
        result = subprocess.run(["node", "--version"], capture_output=True, text=True, timeout=5)
        if result.returncode == 0:
            ver = result.stdout.strip().lstrip("v")
            major = int(ver.split(".")[0])
            check(f"Node.js {ver}", major >= 18, "Need 18+" if major < 18 else "")
        else:
            check("Node.js", False, "Install from https://nodejs.org")
    except FileNotFoundError:
        check("Node.js", False, "Install from https://nodejs.org")

    # Check that npm install has been run
    frontend_modules = os.path.join(os.path.dirname(os.path.abspath(__file__)), "frontend", "node_modules")
    check(
        "Frontend dependencies",
        os.path.isdir(frontend_modules),
        "Run: cd frontend && npm install" if not os.path.isdir(frontend_modules) else "",
    )

    try:
        sys.path.insert(0, ".")
        from agents import Agent
        a = Agent(name="test", role="test", instructions="test")
        check("Agent class", True)
    except Exception as e:
        check("Agent class", False, str(e))

    try:
        import urllib.request
        resp = urllib.request.urlopen("http://localhost:8002/api/agents", timeout=2)
        check("Backend reachable", resp.status == 200)
    except Exception:
        check("Backend reachable", False, "Start with: python -m uvicorn backend.main:app --reload --port 8002")

    total = CHECKS_PASSED + CHECKS_FAILED
    print(f"\n  Results: {CHECKS_PASSED}/{total} checks passed\n")

    if CHECKS_FAILED > 0:
        print("  Fix the issues above before the workshop starts.")
        print("  Ask for help if you get stuck!\n")
        sys.exit(1)
    else:
        print("  All good — you're ready for the workshop!\n")


if __name__ == "__main__":
    main()
