from agents import Agent

# ── EXAMPLE ─────────────────────────────────────────────────
# This agent is done for you. Read it to see how agents work.

site_researcher = Agent(
    name="Site Researcher",
    role="Gather climate, energy grid, and building code data for the project site",
    instructions="""You are a site research specialist. Given a building location
    and program type, research and report:
    - ASHRAE climate zone and whether heating or cooling dominates
    - Local energy grid carbon intensity and renewable mix
    - Applicable energy code (IECC year, ASHRAE 90.1, or local equivalent)
    - Key climate risks (flooding, wildfire, extreme heat, freeze-thaw)
    - Any local green building mandates or incentives

    Be specific to the actual location. Use real data, not generalities.
    Return your findings as structured JSON.""",
    color="#4A90D9",
    icon="globe",
)


# ── YOUR ADVOCATES ─────────────────────────────────────────
# Create at least 2 agents that argue from DIFFERENT perspectives.
# Each agent should care about ONE thing and take a strong position.
#
# Ideas: energy efficiency, natural daylight, embodied carbon,
#        climate resilience, occupant comfort, cost, acoustics...
#
# Tips:
#   - Be specific and opinionated ("WWR must be below 0.30")
#   - Reference real data ("per ASHRAE 90.1...")
#   - Tell the agent what NOT to consider so it stays focused
#   - More detail = better output
#
# See SETUP.md → Step 5 for a complete example you can copy and modify.

advocates = [
    # TODO: Add your first advocate here

    # TODO: Add your second advocate here
]


# ── MANAGER ────────────────────────────────────────────────
# The manager reads ALL advocate positions and resolves conflicts.
# Tell it HOW to decide — don't let it just summarize.

manager = Agent(
    name="Design Arbitrator",
    role="Resolve conflicts between advocates and propose final geometry",
    instructions="""You are the design arbitrator. You have received positions from
    multiple environmental advocates who each argue from a single perspective.

    Your job:
    1. AGREEMENTS: List the points where all advocates agree. These are easy wins.
    2. CONFLICTS: Identify where advocates disagree. For each conflict:
       - Name the specific issue (e.g., "window-to-wall ratio on south facade")
       - State each advocate's position with their proposed number
       - Make a decision. Do NOT average. Choose the position that best serves
         the overall building performance, and explain what you sacrificed and why.
    3. FINAL VERDICT: Write 2-3 sentences summarizing your recommended design direction.
    4. SUGGESTED GEOMETRY: Propose specific values for L, W, H, floors, wwr, and orientation.
       These should reflect your conflict resolutions.
    5. CONSTRAINT PACKET: Produce numeric bounds that a parametric model could use:
       - max_sv_ratio, min_south_pct, max_wwr_east, max_wwr_west, target_wwr_south, etc.
       Only include constraints that emerged from the debate.

    Be decisive. A building that's mediocre at everything is worse than one that
    excels at two things and consciously accepts a tradeoff on the third.""",
    color="#6B7280",
    icon="users",
)
