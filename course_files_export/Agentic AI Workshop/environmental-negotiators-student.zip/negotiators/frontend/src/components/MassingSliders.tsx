import { Slider } from "@/components/ui/slider";
import type { SliderValues } from "@/types";

interface MassingSlidersProps {
  values: SliderValues;
  onChange: (v: SliderValues) => void;
  disabled?: boolean;
}

function getCardinal(deg: number): string {
  const dirs = ["N", "NE", "E", "SE", "S", "SW", "W", "NW"];
  return dirs[Math.round(deg / 45) % 8];
}

const sliderConfig = [
  { key: "L", label: "Length (L)", min: 5, max: 100, step: 1, unit: "m" },
  { key: "W", label: "Width (W)", min: 5, max: 100, step: 1, unit: "m" },
  { key: "H", label: "Height (H)", min: 3, max: 100, step: 1, unit: "m" },
  { key: "floors", label: "Floors", min: 1, max: 30, step: 1, unit: "" },
  { key: "wwr", label: "Glazing (WWR)", min: 0.1, max: 0.9, step: 0.05, unit: "%" },
  { key: "orientation", label: "Orientation", min: 0, max: 359, step: 1, unit: "°" },
  { key: "northAngle", label: "North Angle", min: 0, max: 359, step: 1, unit: "°" },
] as const;

export function MassingSliders({ values, onChange, disabled }: MassingSlidersProps) {
  function handleChange(key: keyof SliderValues, newVal: number) {
    onChange({ ...values, [key]: newVal });
  }

  function formatValue(key: string, val: number): string {
    if (key === "wwr") return `${Math.round(val * 100)}%`;
    if (key === "orientation") return `${val}° ${getCardinal(val)}`;
    if (key === "northAngle") return `${val}°`;
    return `${val}${key === "floors" ? "" : "m"}`;
  }

  return (
    <div className="flex flex-col gap-4">
      {sliderConfig.map(({ key, label, min, max, step }) => (
        <div key={key} className="flex flex-col gap-1.5">
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">{label}</span>
            <span className="font-medium tabular-nums">
              {formatValue(key, values[key as keyof SliderValues])}
            </span>
          </div>
          <Slider
            min={min}
            max={max}
            step={step}
            value={[values[key as keyof SliderValues]]}
            onValueChange={(val: number | readonly number[]) => {
              const v = Array.isArray(val) ? val[0] : val as number;
              handleChange(key as keyof SliderValues, v);
            }}
            disabled={disabled}
          />
        </div>
      ))}
    </div>
  );
}
