import { useState } from "react";
import { Play, Square, Bot, FlaskConical } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { MassingSliders } from "./MassingSliders";
import { ObjUpload } from "./ObjUpload";
import { IsoPreview } from "./IsoPreview";
import { FacadeChart } from "./FacadeChart";
import { MetricCards } from "./MetricCards";
import type { SliderValues, GeometryPacket, AgentInfo, PriorityLevel } from "@/types";

const PROGRAMS = [
  "Office",
  "Higher Education",
  "Residential",
  "Healthcare",
  "Retail",
  "Mixed Use",
  "Cultural",
  "Industrial",
];

interface InputPanelProps {
  sliders: SliderValues;
  onSlidersChange: (v: SliderValues) => void;
  geometry: GeometryPacket;
  onObjUpload: (geometry: GeometryPacket) => void;
  site: string;
  onSiteChange: (s: string) => void;
  program: string;
  onProgramChange: (p: string) => void;
  agents: AgentInfo[];
  onTestAgent: (name: string) => void;
  onRunDebate: (quick: boolean) => void;
  onStopDebate: () => void;
  isRunning: boolean;
  constraints?: Record<string, number>;
  priorities: Record<string, PriorityLevel>;
  onPrioritiesChange: (p: Record<string, PriorityLevel>) => void;
}

const PRIORITY_LEVELS: PriorityLevel[] = ["High", "Medium", "Low"];
const PRIORITY_COLORS: Record<PriorityLevel, string> = {
  High: "text-red-500",
  Medium: "text-amber-500",
  Low: "text-slate-400",
};

export function InputPanel({
  sliders,
  onSlidersChange,
  geometry,
  onObjUpload,
  site,
  onSiteChange,
  program,
  onProgramChange,
  agents,
  onTestAgent,
  onRunDebate,
  onStopDebate,
  isRunning,
  constraints,
  priorities,
  onPrioritiesChange,
}: InputPanelProps) {
  const [selectedAgent, setSelectedAgent] = useState<string>(agents[0]?.name ?? "");

  const advocateAgents = agents.filter((a) => a.type === "advocate");

  return (
    <div className="flex flex-col gap-5 p-4 h-full overflow-y-auto">
      {/* 3D Preview — top of panel */}
      <IsoPreview geometry={geometry} constraintPacket={constraints} northAngle={sliders.northAngle} />

      <Separator />

      {/* Site + Program */}
      <div className="flex flex-col gap-3">
        <div className="flex flex-col gap-1.5">
          <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
            Site Address
          </label>
          <Input
            placeholder="e.g. 1400 NE Campus Pkwy, Seattle, WA"
            value={site}
            onChange={(e) => onSiteChange(e.target.value)}
          />
        </div>

        <div className="flex flex-col gap-1.5">
          <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
            Building Program
          </label>
          <Select value={program} onValueChange={(v) => v !== null && onProgramChange(v)}>
            <SelectTrigger className="w-full">
              <SelectValue placeholder="Select program" />
            </SelectTrigger>
            <SelectContent>
              {PROGRAMS.map((p) => (
                <SelectItem key={p} value={p}>
                  {p}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <Separator />

      {/* Massing Sliders */}
      <div className="flex flex-col gap-2">
        <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
          Massing Parameters
        </p>
        <MassingSliders values={sliders} onChange={onSlidersChange} disabled={isRunning} />
      </div>

      <Separator />

      {/* OBJ Upload */}
      <div className="flex flex-col gap-2">
        <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
          Import Geometry
        </p>
        <ObjUpload onUpload={onObjUpload} />
      </div>

      <Separator />

      {/* Facade Chart */}
      <FacadeChart facadeAreas={geometry.facade_areas} />

      {/* Metric Cards */}
      <MetricCards geometry={geometry} constraints={constraints} />

      <Separator />

      {/* Advocate Priorities */}
      {advocateAgents.length > 0 && (
        <div className="flex flex-col gap-2">
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
            Advocate Priorities
          </p>
          <div className="flex flex-col gap-1.5">
            {advocateAgents.map((a) => {
              const level = priorities[a.name] ?? "Medium";
              return (
                <div key={a.name} className="flex items-center gap-2">
                  <span
                    className="size-2 rounded-full shrink-0"
                    style={{ backgroundColor: a.color }}
                  />
                  <span className="text-xs truncate flex-1">{a.name}</span>
                  <Select
                    value={level}
                    onValueChange={(v) =>
                      onPrioritiesChange({ ...priorities, [a.name]: v as PriorityLevel })
                    }
                  >
                    <SelectTrigger className="w-[90px] h-7 text-[11px]" disabled={isRunning}>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {PRIORITY_LEVELS.map((p) => (
                        <SelectItem key={p} value={p}>
                          <span className={PRIORITY_COLORS[p]}>{p}</span>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Test Agent */}
      {advocateAgents.length > 0 && (
        <div className="flex flex-col gap-2">
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
            Test Single Agent
          </p>
          <div className="flex gap-2">
            <Select
              value={selectedAgent}
              onValueChange={(v) => v !== null && setSelectedAgent(v)}
            >
              <SelectTrigger className="flex-1" disabled={isRunning}>
                <SelectValue placeholder="Select agent" />
              </SelectTrigger>
              <SelectContent>
                {advocateAgents.map((a) => (
                  <SelectItem key={a.name} value={a.name}>
                    {a.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button
              variant="outline"
              size="sm"
              disabled={isRunning || !selectedAgent}
              onClick={() => selectedAgent && onTestAgent(selectedAgent)}
            >
              <FlaskConical className="size-3.5" />
              Test
            </Button>
          </div>
        </div>
      )}

      {/* Run Debate */}
      {isRunning ? (
        <Button
          className="w-full"
          size="lg"
          variant="destructive"
          onClick={onStopDebate}
        >
          <Square className="size-4" />
          Stop Debate
        </Button>
      ) : (
        <div className="flex gap-2">
          <Button
            className="flex-1"
            size="lg"
            variant="outline"
            onClick={() => onRunDebate(true)}
          >
            <Play className="size-4" />
            Quick
          </Button>
          <Button
            className="flex-1"
            size="lg"
            onClick={() => onRunDebate(false)}
          >
            <Play className="size-4" />
            Full Debate
          </Button>
        </div>
      )}
    </div>
  );
}
