import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Cell,
  LabelList,
  ResponsiveContainer,
} from "recharts";
import type { FacadeAreas } from "@/types";

interface FacadeChartProps {
  facadeAreas: FacadeAreas;
}

const DIR_COLORS: Record<string, string> = {
  S: "#f59e0b",
  N: "#3b82f6",
  E: "#9ca3af",
  W: "#6b7280",
};

export function FacadeChart({ facadeAreas }: FacadeChartProps) {
  const total = Object.values(facadeAreas).reduce((a, b) => a + b, 0);
  const data = (["S", "E", "N", "W"] as const).map((dir) => ({
    dir,
    area: facadeAreas[dir],
    pct: total > 0 ? Math.round((facadeAreas[dir] / total) * 100) : 0,
  }));

  return (
    <div className="w-full">
      <p className="mb-2 text-xs font-medium text-muted-foreground uppercase tracking-wide">
        Facade Areas by Direction
      </p>
      <ResponsiveContainer width="100%" height={120}>
        <BarChart
          data={data}
          layout="vertical"
          margin={{ left: 8, right: 48, top: 4, bottom: 4 }}
        >
          <XAxis type="number" hide />
          <YAxis
            type="category"
            dataKey="dir"
            width={20}
            tick={{ fontSize: 12, fontWeight: 600 }}
            axisLine={false}
            tickLine={false}
          />
          <Bar dataKey="area" radius={[0, 4, 4, 0]} isAnimationActive={false}>
            {data.map(({ dir }) => (
              <Cell key={dir} fill={DIR_COLORS[dir]} />
            ))}
            <LabelList
              dataKey="pct"
              position="right"
              formatter={(v: unknown) => `${v}%`}
              style={{ fontSize: 11, fill: "#6b7280", pointerEvents: "none" }}
            />
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
