import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import type { GeometryPacket } from "@/types";

interface MetricCardsProps {
  geometry: GeometryPacket;
  constraints?: Record<string, number>;
}

function isAmber(key: string, value: number): boolean {
  if (key === "sv_ratio") return value > 0.5;
  if (key === "south_glazing_ratio") return value < 0.08 || value > 0.35;
  return false;
}

export function MetricCards({ geometry, constraints }: MetricCardsProps) {
  const totalWall = Object.values(geometry.facade_areas).reduce((a, b) => a + b, 0);
  const southGlazing = geometry.facade_areas.S * geometry.wwr;
  const totalGlazing = totalWall * geometry.wwr;
  const metrics = [
    {
      key: "sv_ratio",
      label: "S/V Ratio",
      value: geometry.sv_ratio.toFixed(2),
      rawValue: geometry.sv_ratio,
      constraintKey: "sv_ratio",
    },
    {
      key: "form_factor",
      label: "Form Factor",
      value: geometry.form_factor.toFixed(2),
      rawValue: geometry.form_factor,
      constraintKey: "form_factor",
    },
    {
      key: "south_glazing",
      label: "South Glazing",
      value: `${Math.round(southGlazing).toLocaleString()} m²`,
      rawValue: southGlazing,
      constraintKey: "south_glazing",
    },
    {
      key: "total_glazing",
      label: "Total Glazing",
      value: `${Math.round(totalGlazing).toLocaleString()} m²`,
      rawValue: totalGlazing,
      constraintKey: "total_glazing",
    },
    {
      key: "floor_area",
      label: "Floor Area",
      value: `${geometry.floor_area.toLocaleString()} m²`,
      rawValue: geometry.floor_area,
      constraintKey: "floor_area",
    },
    {
      key: "volume",
      label: "Volume",
      value: `${geometry.volume.toLocaleString()} m³`,
      rawValue: geometry.volume,
      constraintKey: "volume",
    },
  ];

  return (
    <div className="grid grid-cols-2 gap-2">
      {metrics.map(({ key, label, value, rawValue, constraintKey }) => {
        const amber = isAmber(key, rawValue);
        const constraintVal = constraints?.[constraintKey];
        const passes =
          constraintVal !== undefined ? rawValue <= constraintVal : null;

        return (
          <Card
            key={key}
            size="sm"
            className={amber ? "border-amber-400 bg-amber-50 dark:bg-amber-950/20" : ""}
          >
            <CardContent className="flex flex-col gap-0.5 py-2">
              <span className="text-[10px] text-muted-foreground">{label}</span>
              <span
                className={`text-sm font-semibold tabular-nums ${amber ? "text-amber-700 dark:text-amber-400" : ""}`}
              >
                {value}
              </span>
              {passes !== null && (
                <Badge
                  variant={passes ? "secondary" : "destructive"}
                  className="w-fit text-[9px]"
                >
                  {passes ? "Pass" : "Fail"}
                </Badge>
              )}
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
