import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  Cell,
} from "recharts";

interface FacadeWWRChartProps {
  currentWWR: number;
  constraintPacket: Record<string, number>;
}

const DIRECTION_COLORS: Record<string, string> = {
  N: "#3b82f6",
  S: "#f59e0b",
  E: "#a78bfa",
  W: "#f87171",
};

function getRecommended(dir: string, constraints: Record<string, number>, currentWWR: number): number {
  const key = dir.toLowerCase();
  // Try target first, then max
  const target = constraints[`target_wwr_${key}`];
  if (target !== undefined) return target;
  const max = constraints[`max_wwr_${key}`];
  if (max !== undefined) return max;
  return currentWWR;
}

export function FacadeWWRChart({ currentWWR, constraintPacket }: FacadeWWRChartProps) {
  const directions = ["N", "S", "E", "W"] as const;

  const data = directions.map((dir) => ({
    direction: dir,
    "Current WWR": Math.round(currentWWR * 100),
    Recommended: Math.round(getRecommended(dir, constraintPacket, currentWWR) * 100),
    color: DIRECTION_COLORS[dir],
  }));

  return (
    <div className="w-full">
      <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
        Per-Facade WWR Breakdown (%)
      </p>
      <ResponsiveContainer width="100%" height={200}>
        <BarChart
          layout="vertical"
          data={data}
          margin={{ top: 4, right: 24, bottom: 4, left: 16 }}
          barCategoryGap="30%"
          barGap={4}
        >
          <CartesianGrid horizontal={false} stroke="#334155" strokeOpacity={0.2} />
          <XAxis
            type="number"
            domain={[0, 100]}
            tickFormatter={(v) => `${v}%`}
            tick={{ fill: "#94a3b8", fontSize: 10 }}
            tickLine={false}
          />
          <YAxis
            type="category"
            dataKey="direction"
            tick={{ fill: "#94a3b8", fontSize: 11 }}
            tickLine={false}
            axisLine={false}
            width={20}
          />
          <Tooltip
            formatter={(value) => [`${value}%`]}
            contentStyle={{
              background: "#1e293b",
              border: "1px solid #334155",
              borderRadius: 6,
              fontSize: 11,
            }}
            labelStyle={{ color: "#94a3b8" }}
            itemStyle={{ color: "#e2e8f0" }}
          />
          <Legend wrapperStyle={{ fontSize: 11, color: "#94a3b8" }} />
          <Bar dataKey="Current WWR" fill="#64748b" radius={[0, 3, 3, 0]}>
            {data.map((_, i) => (
              <Cell key={i} fill="#64748b" fillOpacity={0.7} />
            ))}
          </Bar>
          <Bar dataKey="Recommended" radius={[0, 3, 3, 0]}>
            {data.map((entry, i) => (
              <Cell key={i} fill={entry.color} fillOpacity={0.85} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
