import { CheckCircle2, AlertTriangle, Loader2 } from "lucide-react";
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import type { AgentResult, ManagerResponse, GeometryPacket, SliderValues } from "@/types";

interface ManagerCardProps {
  result?: AgentResult;
  isLoading?: boolean;
  currentGeometry: GeometryPacket;
  onApply?: (suggested: SliderValues) => void;
}

function isManagerResponse(r: unknown): r is ManagerResponse {
  return (
    typeof r === "object" &&
    r !== null &&
    "agreements" in r &&
    "final_verdict" in r &&
    "suggested_geometry" in r
  );
}

function GeomDiffChip({
  label,
  current,
  suggested,
}: {
  label: string;
  current: number;
  suggested: number;
}) {
  const changed = Math.abs(current - suggested) > 0.001;
  return (
    <span
      className={`inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-medium ${
        changed
          ? "bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-300"
          : "bg-muted text-muted-foreground"
      }`}
    >
      {label}
      {changed && (
        <span className="opacity-70">
          {current} → {suggested}
        </span>
      )}
    </span>
  );
}

export function ManagerCard({ result, isLoading, currentGeometry, onApply }: ManagerCardProps) {
  if (isLoading) {
    return (
      <Card className="relative overflow-hidden border-2 border-purple-200 dark:border-purple-900">
        <div className="absolute top-0 left-0 right-0 h-1 bg-purple-500" />
        <CardHeader className="pt-5">
          <CardTitle className="flex items-center gap-2 text-base">
            <Loader2 className="size-4 animate-spin text-purple-500" />
            Manager Resolving…
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col gap-2">
            <div className="h-3 w-full rounded bg-muted animate-pulse" />
            <div className="h-3 w-4/5 rounded bg-muted animate-pulse" />
            <div className="h-3 w-2/3 rounded bg-muted animate-pulse" />
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!result || !isManagerResponse(result.response)) return null;

  const raw = result.response;
  // Normalize: model may return strings instead of arrays
  const mgr = {
    ...raw,
    agreements: Array.isArray(raw.agreements) ? raw.agreements : (raw.agreements ? [String(raw.agreements)] : []),
    conflicts: Array.isArray(raw.conflicts) ? raw.conflicts : (raw.conflicts ? [raw.conflicts] : []),
  } as ManagerResponse;
  const sg = mgr.suggested_geometry;
  const dims = currentGeometry.dims;

  const diffFields: { key: keyof SliderValues; label: string; current: number }[] = [
    { key: "L", label: "L", current: dims.L },
    { key: "W", label: "W", current: dims.W },
    { key: "H", label: "H", current: dims.H },
    { key: "floors", label: "Floors", current: dims.floors },
    { key: "wwr", label: "WWR", current: currentGeometry.wwr },
    { key: "orientation", label: "Orient°", current: currentGeometry.orientation },
  ];

  return (
    <Card className="relative overflow-hidden border-2 border-purple-200 dark:border-purple-900">
      <div className="absolute top-0 left-0 right-0 h-1 bg-purple-500" />
      <CardHeader className="pt-5">
        <CardTitle className="flex items-center gap-2 text-base">
          <CheckCircle2 className="size-5 text-purple-500" />
          Manager Decision
        </CardTitle>
      </CardHeader>

      <CardContent className="flex flex-col gap-4">
        {/* Agreements */}
        {mgr.agreements?.length > 0 && (
          <div className="flex flex-col gap-2">
            <h4 className="text-xs font-semibold uppercase tracking-wide text-teal-700 dark:text-teal-400">
              Agreements
            </h4>
            <ul className="flex flex-col gap-1.5">
              {mgr.agreements.map((a, i) => (
                <li
                  key={i}
                  className="border-l-4 border-teal-400 bg-teal-50 dark:bg-teal-950/20 pl-3 py-1.5 text-sm rounded-r-md"
                >
                  {a}
                </li>
              ))}
            </ul>
          </div>
        )}

        {/* Conflicts */}
        {mgr.conflicts?.length > 0 && (
          <div className="flex flex-col gap-2">
            <h4 className="text-xs font-semibold uppercase tracking-wide text-amber-700 dark:text-amber-400">
              Conflicts Resolved
            </h4>
            <div className="flex flex-col gap-3">
              {mgr.conflicts.map((c, i) => (
                <div
                  key={i}
                  className="rounded-lg border border-amber-200 dark:border-amber-900 p-3 flex flex-col gap-2"
                >
                  <div className="flex items-start gap-2">
                    <AlertTriangle className="size-3.5 shrink-0 mt-0.5 text-amber-500" />
                    <span className="text-xs font-medium">{c.issue}</span>
                  </div>
                  {c.positions && Object.keys(c.positions).length > 0 && (
                    <div className="flex flex-wrap gap-1">
                      {Object.entries(c.positions).map(([agent, pos]) => (
                        <Badge key={agent} variant="outline" className="text-[10px]">
                          {agent}: {pos}
                        </Badge>
                      ))}
                    </div>
                  )}
                  {c.resolution && (
                    <p className="text-xs text-muted-foreground italic">{c.resolution}</p>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Final verdict */}
        {mgr.final_verdict && (
          <div className="flex flex-col gap-1.5">
            <h4 className="text-xs font-semibold uppercase tracking-wide text-purple-700 dark:text-purple-400">
              Final Verdict
            </h4>
            <p className="text-sm leading-relaxed">{mgr.final_verdict}</p>
          </div>
        )}

        {/* Geometry diff chips */}
        {sg && (
          <div className="flex flex-col gap-2">
            <h4 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
              Suggested Changes
            </h4>
            <div className="flex flex-wrap gap-1.5">
              {diffFields.map(({ key, label, current }) => (
                <GeomDiffChip
                  key={key}
                  label={label}
                  current={current}
                  suggested={sg[key]}
                />
              ))}
            </div>
          </div>
        )}

        {/* Constraint packet */}
        {mgr.constraint_packet && Object.keys(mgr.constraint_packet).length > 0 && (
          <div className="flex flex-col gap-2">
            <h4 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
              Performance Constraints
            </h4>
            <div className="flex flex-wrap gap-1.5">
              {Object.entries(mgr.constraint_packet).map(([k, v]) => (
                <Badge key={k} variant="secondary" className="text-[10px] font-mono">
                  {k}: {typeof v === "number" ? v.toFixed(2) : v}
                </Badge>
              ))}
            </div>
          </div>
        )}
      </CardContent>

      {sg && onApply && (
        <CardFooter>
          <Button className="w-full bg-purple-600 hover:bg-purple-700 text-white" onClick={() => onApply(sg)}>
            Apply Changes
          </Button>
        </CardFooter>
      )}
    </Card>
  );
}
