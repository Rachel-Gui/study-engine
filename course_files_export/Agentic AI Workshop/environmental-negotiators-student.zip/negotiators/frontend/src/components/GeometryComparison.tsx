import { useRef, useEffect } from "react";
import * as THREE from "three";
import { computeGeometry } from "@/lib/geometry";
import type { GeometryPacket, SliderValues } from "@/types";

interface GeometryComparisonProps {
  currentGeometry: GeometryPacket;
  suggestedGeometry: SliderValues | null;
}

interface MeshViewProps {
  verts: number[][];
  tris: number[][];
  color: number;
  label: string;
  dims: { L: number; W: number; H: number };
}

function MeshView({ verts, tris, color, label, dims }: MeshViewProps) {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    while (container.firstChild) {
      container.removeChild(container.firstChild);
    }

    const width = container.clientWidth || 200;
    const height = 180;

    const threeGeom = new THREE.BufferGeometry();
    const positions: number[] = [];
    for (const tri of tris) {
      const v0 = verts[tri[0]];
      const v1 = verts[tri[1]];
      const v2 = verts[tri[2]];
      if (!v0 || !v1 || !v2) continue;
      positions.push(v0[0], v0[1], v0[2]);
      positions.push(v1[0], v1[1], v1[2]);
      positions.push(v2[0], v2[1], v2[2]);
    }
    threeGeom.setAttribute("position", new THREE.Float32BufferAttribute(positions, 3));
    threeGeom.computeVertexNormals();
    threeGeom.computeBoundingBox();

    const bbox = threeGeom.boundingBox!;
    const center = new THREE.Vector3();
    bbox.getCenter(center);
    const size = new THREE.Vector3();
    bbox.getSize(size);
    const maxDim = Math.max(size.x, size.y, size.z);

    const scene = new THREE.Scene();

    const material = new THREE.MeshPhongMaterial({
      color,
      flatShading: true,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.85,
    });
    const mesh = new THREE.Mesh(threeGeom, material);
    mesh.position.sub(center);
    scene.add(mesh);

    const edges = new THREE.EdgesGeometry(threeGeom, 15);
    const lineMat = new THREE.LineBasicMaterial({ color: 0x1e293b });
    const line = new THREE.LineSegments(edges, lineMat);
    line.position.sub(center);
    scene.add(line);

    const aspect = width / height;
    const frustum = maxDim * 0.8;
    const camera = new THREE.OrthographicCamera(
      -frustum * aspect, frustum * aspect,
      frustum, -frustum,
      -maxDim * 5, maxDim * 5
    );
    const d = maxDim * 2;
    camera.position.set(d, d * 0.8, d);
    camera.lookAt(0, 0, 0);
    camera.updateProjectionMatrix();

    scene.add(new THREE.AmbientLight(0xffffff, 0.6));
    const dirLight = new THREE.DirectionalLight(0xffffff, 0.8);
    dirLight.position.set(d, d * 1.5, d * 0.5);
    scene.add(dirLight);
    const fillLight = new THREE.DirectionalLight(0xffffff, 0.3);
    fillLight.position.set(-d, d * 0.5, -d);
    scene.add(fillLight);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(window.devicePixelRatio);
    renderer.setClearColor(0x000000, 0);
    container.appendChild(renderer.domElement);
    renderer.render(scene, camera);

    return () => {
      renderer.dispose();
      threeGeom.dispose();
      material.dispose();
      edges.dispose();
      lineMat.dispose();
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
    };
  }, [verts, tris, color]);

  return (
    <div className="flex flex-col items-center gap-1 flex-1">
      <p className="text-xs font-medium text-muted-foreground">{label}</p>
      <div
        ref={containerRef}
        className="w-full rounded-lg bg-slate-50 dark:bg-slate-900 overflow-hidden"
        style={{ height: 180 }}
      />
      <p className="text-[10px] text-muted-foreground">
        {dims.L}&times;{dims.W}&times;{dims.H}m
      </p>
    </div>
  );
}

/** Build a simple box mesh from dimensions */
function boxMesh(L: number, W: number, H: number): { verts: number[][]; tris: number[][] } {
  return {
    verts: [
      [0, 0, 0], [L, 0, 0], [L, 0, W], [0, 0, W],
      [0, H, 0], [L, H, 0], [L, H, W], [0, H, W],
    ],
    tris: [
      [0, 2, 1], [0, 3, 2],
      [4, 5, 6], [4, 6, 7],
      [0, 1, 5], [0, 5, 4],
      [2, 3, 7], [2, 7, 6],
      [0, 4, 7], [0, 7, 3],
      [1, 2, 6], [1, 6, 5],
    ],
  };
}

/** Scale OBJ vertices from original dims to target dims */
function scaleVerts(
  verts: number[][],
  origDims: { L: number; W: number; H: number },
  targetDims: { L: number; W: number; H: number },
): number[][] {
  const sx = origDims.L > 0 ? targetDims.L / origDims.L : 1;
  const sy = origDims.H > 0 ? targetDims.H / origDims.H : 1;
  const sz = origDims.W > 0 ? targetDims.W / origDims.W : 1;
  return verts.map(v => [v[0] * sx, v[1] * sy, v[2] * sz]);
}

export function GeometryComparison({
  currentGeometry,
  suggestedGeometry,
}: GeometryComparisonProps) {
  if (!suggestedGeometry) return null;

  const suggested = computeGeometry(suggestedGeometry);
  const cur = currentGeometry.dims;
  const sug = suggested.dims;

  const hasObjMesh = !!(
    currentGeometry.vertices &&
    currentGeometry.faces &&
    currentGeometry.vertices.length > 3
  );

  // Current: use OBJ mesh if available, otherwise box
  let curVerts: number[][];
  let curTris: number[][];
  if (hasObjMesh) {
    curVerts = currentGeometry.vertices!;
    curTris = currentGeometry.faces!;
  } else {
    const box = boxMesh(cur.L, cur.W, cur.H);
    curVerts = box.verts;
    curTris = box.tris;
  }

  // Suggested: scale the OBJ mesh to suggested dims, or build a box
  let sugVerts: number[][];
  let sugTris: number[][];
  if (hasObjMesh) {
    // The currentGeometry.vertices are already at the current slider scale.
    // We need to find the original OBJ dims to compute the right scale.
    // Since currentGeometry.dims reflects current sliders, we scale from cur → sug.
    sugVerts = scaleVerts(curVerts, cur, sug);
    sugTris = curTris; // same topology, just scaled vertices
  } else {
    const box = boxMesh(sug.L, sug.W, sug.H);
    sugVerts = box.verts;
    sugTris = box.tris;
  }

  // Highlight changed dimensions
  const lChanged = Math.abs(cur.L - sug.L) > 0.1;
  const wChanged = Math.abs(cur.W - sug.W) > 0.1;
  const hChanged = Math.abs(cur.H - sug.H) > 0.1;

  const changedLabels: string[] = [];
  if (lChanged) changedLabels.push(`L: ${cur.L}m → ${sug.L}m`);
  if (wChanged) changedLabels.push(`W: ${cur.W}m → ${sug.W}m`);
  if (hChanged) changedLabels.push(`H: ${cur.H}m → ${sug.H}m`);

  return (
    <div className="w-full">
      <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
        Geometry Comparison
      </p>
      <div className="flex gap-4">
        <MeshView verts={curVerts} tris={curTris} dims={cur} color={0x3b82f6} label="Current" />
        <MeshView verts={sugVerts} tris={sugTris} dims={sug} color={0x22c55e} label="Suggested" />
      </div>
      {changedLabels.length > 0 && (
        <div className="mt-2 flex flex-wrap gap-2">
          {changedLabels.map((label) => (
            <span
              key={label}
              className="inline-flex items-center rounded-full bg-green-500/10 px-2 py-0.5 text-[10px] font-medium text-green-400 ring-1 ring-inset ring-green-500/20"
            >
              {label}
            </span>
          ))}
        </div>
      )}
    </div>
  );
}
