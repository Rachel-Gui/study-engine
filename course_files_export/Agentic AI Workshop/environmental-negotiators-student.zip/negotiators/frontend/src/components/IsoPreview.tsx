import { useRef, useEffect, useState } from "react";
import * as THREE from "three";
import type { GeometryPacket } from "@/types";

interface IsoPreviewProps {
  geometry: GeometryPacket;
  constraintPacket?: Record<string, number>;
  northAngle?: number;
}

/* ── View angles ─────────────────────────────────────────── */

const VIEWS = [
  { id: "iso", label: "3D" },
  { id: "S", label: "S" },
  { id: "N", label: "N" },
  { id: "E", label: "E" },
  { id: "W", label: "W" },
  { id: "top", label: "Top" },
] as const;

function getCameraPos(view: string, d: number): [number, number, number] {
  switch (view) {
    case "S":   return [0, d * 0.35, d * 2.2];
    case "N":   return [0, d * 0.35, -d * 2.2];
    case "E":   return [d * 2.2, d * 0.35, 0];
    case "W":   return [-d * 2.2, d * 0.35, 0];
    case "top": return [0, d * 3, 0.01];
    default:    return [d, d * 0.8, d];
  }
}

function getCameraUp(view: string): [number, number, number] {
  return view === "top" ? [0, 0, -1] : [0, 1, 0];
}

/* ── Constraint-based face coloring (box only) ───────────── */

function getFaceColor(
  triIndex: number,
  cp: Record<string, number>,
  geometry: GeometryPacket,
): THREE.Color {
  if (Object.keys(cp).length === 0) return new THREE.Color(0xb0bec5);
  const { wwr, sv_ratio } = geometry;
  const dirMap: Record<number, string | null> = {
    0: null, 1: null, 2: null, 3: null,
    4: "N", 5: "N", 6: "S", 7: "S",
    8: "W", 9: "W", 10: "E", 11: "E",
  };
  const dir = dirMap[triIndex] ?? null;
  const maxSV = cp["max_sv_ratio"];
  if (dir === null && maxSV !== undefined) {
    return sv_ratio > maxSV ? new THREE.Color(0xf59e0b) : new THREE.Color(0x22c55e);
  }
  if (dir === null) return new THREE.Color(0x94a3b8);
  const lo = dir.toLowerCase();
  const maxW = cp[`max_wwr_${lo}`];
  const tgtW = cp[`target_wwr_${lo}`];
  let bad = false;
  if (maxW !== undefined && wwr > maxW) bad = true;
  if (tgtW !== undefined && dir === "S" && wwr < tgtW * 0.8) bad = true;
  if (bad) return new THREE.Color(0xef4444);
  if (maxW !== undefined || tgtW !== undefined) return new THREE.Color(0x22c55e);
  return new THREE.Color(0xb0bec5);
}

/* ── Mesh-plane intersection (floor lines for OBJ) ──────── */

function meshFloorIntersect(verts: number[][], tris: number[][], yPlane: number): number[] {
  const eps = 0.01;
  const segs: number[] = [];
  for (const tri of tris) {
    const v0 = verts[tri[0]], v1 = verts[tri[1]], v2 = verts[tri[2]];
    if (!v0 || !v1 || !v2) continue;
    const pts: number[][] = [];
    for (const [a, b] of [[v0, v1], [v1, v2], [v2, v0]] as [number[], number[]][]) {
      const da = a[1] - yPlane, db = b[1] - yPlane;
      if ((da > eps && db < -eps) || (da < -eps && db > eps)) {
        const t = da / (da - db);
        pts.push([a[0] + t * (b[0] - a[0]), yPlane, a[2] + t * (b[2] - a[2])]);
      }
    }
    if (pts.length === 2) segs.push(...pts[0], ...pts[1]);
  }
  return segs;
}

/* ── Triangle-to-Y-band clipping (glazing for OBJ) ──────── */

function clipAgainstY(poly: number[][], yP: number, keepAbove: boolean): number[][] {
  const out: number[][] = [];
  for (let i = 0; i < poly.length; i++) {
    const c = poly[i], nx = poly[(i + 1) % poly.length];
    const cIn = keepAbove ? c[1] >= yP - 0.001 : c[1] <= yP + 0.001;
    const nIn = keepAbove ? nx[1] >= yP - 0.001 : nx[1] <= yP + 0.001;
    if (cIn) out.push(c);
    if (cIn !== nIn) {
      const t = (yP - c[1]) / (nx[1] - c[1]);
      out.push([c[0] + t * (nx[0] - c[0]), yP, c[2] + t * (nx[2] - c[2])]);
    }
  }
  return out;
}

function clipTriToYBand(v0: number[], v1: number[], v2: number[], yMin: number, yMax: number): number[][] {
  let p: number[][] = [v0, v1, v2];
  p = clipAgainstY(p, yMin, true);
  if (p.length < 3) return [];
  p = clipAgainstY(p, yMax, false);
  return p.length >= 3 ? p : [];
}

/* ── Box helpers ─────────────────────────────────────────── */

function buildBoxFloorLines(
  x0: number, y0: number, z0: number,
  x1: number, y1: number, z1: number,
  floors: number,
): THREE.LineSegments {
  const fh = (y1 - y0) / floors;
  const pts: number[] = [];
  for (let f = 1; f < floors; f++) {
    const y = y0 + f * fh;
    pts.push(x0, y, z0, x1, y, z0);
    pts.push(x0, y, z1, x1, y, z1);
    pts.push(x0, y, z0, x0, y, z1);
    pts.push(x1, y, z0, x1, y, z1);
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute("position", new THREE.Float32BufferAttribute(pts, 3));
  return new THREE.LineSegments(g, new THREE.LineBasicMaterial({ color: 0x1e293b }));
}

function buildBoxGlazing(
  x0: number, y0: number, z0: number,
  x1: number, y1: number, z1: number,
  floors: number, wwr: number,
): THREE.Mesh {
  const fh = (y1 - y0) / floors;
  const winH = wwr * fh * 0.9;
  const margin = (fh - winH) / 2;
  const off = 0.03;
  const pos: number[] = [];
  for (let f = 0; f < floors; f++) {
    const yB = y0 + f * fh + margin, yT = yB + winH;
    const faces: [number, number, number, number, number, number, number, number, number, number, number, number][] = [
      [x0, yB, z0 - off, x1, yB, z0 - off, x1, yT, z0 - off, x0, yT, z0 - off],
      [x1, yB, z1 + off, x0, yB, z1 + off, x0, yT, z1 + off, x1, yT, z1 + off],
      [x0 - off, yB, z1, x0 - off, yB, z0, x0 - off, yT, z0, x0 - off, yT, z1],
      [x1 + off, yB, z0, x1 + off, yB, z1, x1 + off, yT, z1, x1 + off, yT, z0],
    ];
    for (const [ax, ay, az, bx, by, bz, cx, cy, cz, dx, dy, dz] of faces) {
      pos.push(ax, ay, az, bx, by, bz, cx, cy, cz);
      pos.push(ax, ay, az, cx, cy, cz, dx, dy, dz);
    }
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
  g.computeVertexNormals();
  const m = new THREE.MeshPhongMaterial({
    color: 0x60a5fa, transparent: true, opacity: 0.45,
    side: THREE.DoubleSide, depthWrite: false,
  });
  return new THREE.Mesh(g, m);
}

/* ── OBJ helpers ─────────────────────────────────────────── */

function buildObjFloorLines(
  verts: number[][], tris: number[][],
  yMin: number, yMax: number, floors: number,
): THREE.LineSegments {
  const fh = (yMax - yMin) / floors;
  const pts: number[] = [];
  for (let f = 1; f < floors; f++) {
    pts.push(...meshFloorIntersect(verts, tris, yMin + f * fh));
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute("position", new THREE.Float32BufferAttribute(pts, 3));
  return new THREE.LineSegments(g, new THREE.LineBasicMaterial({ color: 0x1e293b }));
}

function buildObjGlazing(
  verts: number[][], tris: number[][],
  yMin: number, yMax: number,
  floors: number, wwr: number,
): THREE.Mesh {
  const fh = (yMax - yMin) / floors;
  const winH = wwr * fh * 0.9;
  const margin = (fh - winH) / 2;
  const pos: number[] = [];
  for (const tri of tris) {
    const v0 = verts[tri[0]], v1 = verts[tri[1]], v2 = verts[tri[2]];
    if (!v0 || !v1 || !v2) continue;
    const ax = v1[0] - v0[0], ay = v1[1] - v0[1], az = v1[2] - v0[2];
    const bx = v2[0] - v0[0], by = v2[1] - v0[1], bz = v2[2] - v0[2];
    const nx = ay * bz - az * by, ny = az * bx - ax * bz, nz = ax * by - ay * bx;
    const len = Math.sqrt(nx * nx + ny * ny + nz * nz);
    if (len < 1e-10) continue;
    if (Math.abs(ny / len) > 0.7) continue;
    const off = 0.05;
    const ux = (nx / len) * off, uz = (nz / len) * off;
    const ov0 = [v0[0] + ux, v0[1], v0[2] + uz];
    const ov1 = [v1[0] + ux, v1[1], v1[2] + uz];
    const ov2 = [v2[0] + ux, v2[1], v2[2] + uz];
    for (let f = 0; f < floors; f++) {
      const bandBot = yMin + f * fh + margin;
      const bandTop = bandBot + winH;
      const clipped = clipTriToYBand(ov0, ov1, ov2, bandBot, bandTop);
      if (clipped.length < 3) continue;
      for (let i = 1; i < clipped.length - 1; i++) {
        pos.push(...clipped[0], ...clipped[i], ...clipped[i + 1]);
      }
    }
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
  g.computeVertexNormals();
  const m = new THREE.MeshPhongMaterial({
    color: 0x60a5fa, transparent: true, opacity: 0.45,
    side: THREE.DoubleSide, depthWrite: false,
    polygonOffset: true, polygonOffsetFactor: -1, polygonOffsetUnits: -1,
  });
  return new THREE.Mesh(g, m);
}

/* ── Component ───────────────────────────────────────────── */

export function IsoPreview({ geometry, constraintPacket = {}, northAngle = 0 }: IsoPreviewProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [viewAngle, setViewAngle] = useState("iso");
  const [compassDeg, setCompassDeg] = useState(0);

  const hasObjMesh = !!(geometry.vertices && geometry.faces && geometry.vertices.length > 3);
  const isObj = geometry.source === "obj";

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;
    while (container.firstChild) container.removeChild(container.firstChild);

    const width = container.clientWidth || 340;
    const height = 280;
    const { L, W, H, floors } = geometry.dims;
    const wwr = geometry.wwr;
    const orientation = geometry.orientation;

    // ── Build mesh geometry ──
    let verts: number[][];
    let tris: number[][];
    if (hasObjMesh) {
      verts = geometry.vertices!;
      tris = geometry.faces!;
    } else {
      verts = [
        [0, 0, 0], [L, 0, 0], [L, 0, W], [0, 0, W],
        [0, H, 0], [L, H, 0], [L, H, W], [0, H, W],
      ];
      tris = [
        [0, 2, 1], [0, 3, 2], [4, 5, 6], [4, 6, 7],
        [0, 1, 5], [0, 5, 4], [2, 3, 7], [2, 7, 6],
        [0, 4, 7], [0, 7, 3], [1, 2, 6], [1, 6, 5],
      ];
    }

    const threeGeom = new THREE.BufferGeometry();
    const positions: number[] = [];
    const colors: number[] = [];
    const useVC = !hasObjMesh && Object.keys(constraintPacket).length > 0;

    for (let i = 0; i < tris.length; i++) {
      const tri = tris[i];
      if (tri.length < 3) continue;
      const a = verts[tri[0]], b = verts[tri[1]], c = verts[tri[2]];
      if (!a || !b || !c) continue;
      positions.push(a[0], a[1], a[2], b[0], b[1], b[2], c[0], c[1], c[2]);
      if (useVC) {
        const col = getFaceColor(i, constraintPacket, geometry);
        colors.push(col.r, col.g, col.b, col.r, col.g, col.b, col.r, col.g, col.b);
      }
    }
    threeGeom.setAttribute("position", new THREE.Float32BufferAttribute(positions, 3));
    if (useVC) threeGeom.setAttribute("color", new THREE.Float32BufferAttribute(colors, 3));
    threeGeom.computeVertexNormals();
    threeGeom.computeBoundingBox();
    const bbox = threeGeom.boundingBox!;
    const center = new THREE.Vector3();
    bbox.getCenter(center);
    const size = new THREE.Vector3();
    bbox.getSize(size);
    const maxDim = Math.max(size.x, size.y, size.z);
    const bbMin = bbox.min;
    const bbMax = bbox.max;

    // ── Scene ──
    const scene = new THREE.Scene();
    const disposables: { dispose(): void }[] = [];

    const mat = new THREE.MeshPhongMaterial({
      color: useVC ? 0xffffff : 0xb0bec5,
      vertexColors: useVC, flatShading: true, side: THREE.DoubleSide,
    });
    const mesh = new THREE.Mesh(threeGeom, mat);
    disposables.push(threeGeom, mat);

    const edgeGeom = new THREE.EdgesGeometry(threeGeom, 15);
    const edgeMat = new THREE.LineBasicMaterial({ color: 0x455a64 });
    const edgeLine = new THREE.LineSegments(edgeGeom, edgeMat);
    disposables.push(edgeGeom, edgeMat);

    const buildingGroup = new THREE.Group();
    mesh.position.sub(center);
    edgeLine.position.sub(center);
    buildingGroup.add(mesh);
    buildingGroup.add(edgeLine);

    // ── Floor lines ──
    if (floors > 1) {
      let floorLines: THREE.LineSegments;
      if (hasObjMesh) {
        floorLines = buildObjFloorLines(verts, tris, bbMin.y, bbMax.y, floors);
      } else {
        floorLines = buildBoxFloorLines(bbMin.x, bbMin.y, bbMin.z, bbMax.x, bbMax.y, bbMax.z, floors);
      }
      floorLines.position.sub(center);
      buildingGroup.add(floorLines);
      disposables.push(floorLines.geometry, floorLines.material as THREE.Material);
    }

    // ── Glazing ──
    if (wwr > 0) {
      let glazing: THREE.Mesh;
      if (hasObjMesh) {
        glazing = buildObjGlazing(verts, tris, bbMin.y, bbMax.y, floors, wwr);
      } else {
        glazing = buildBoxGlazing(bbMin.x, bbMin.y, bbMin.z, bbMax.x, bbMax.y, bbMax.z, floors, wwr);
      }
      glazing.position.sub(center);
      buildingGroup.add(glazing);
      disposables.push(glazing.geometry, glazing.material as THREE.Material);
    }

    // ── Orientation rotation (northAngle only affects compass, not the building) ──
    buildingGroup.rotation.y = (180 - orientation) * Math.PI / 180;
    scene.add(buildingGroup);

    // ── Camera ──
    const aspect = width / height;
    const frustum = maxDim * 0.85;
    const camera = new THREE.OrthographicCamera(
      -frustum * aspect, frustum * aspect, frustum, -frustum,
      -maxDim * 5, maxDim * 5,
    );
    const d = maxDim * 2;
    const [cx, cy, cz] = getCameraPos(viewAngle, d);
    camera.position.set(cx, cy, cz);
    const [ux, uy, uz] = getCameraUp(viewAngle);
    camera.up.set(ux, uy, uz);
    camera.lookAt(0, 0, 0);
    camera.updateProjectionMatrix();

    // ── Compute compass screen rotation ──
    // North in world space = -Z, rotated by northAngle around Y
    const northDir = new THREE.Vector3(0, 0, -1)
      .applyAxisAngle(new THREE.Vector3(0, 1, 0), -northAngle * Math.PI / 180);
    // Project origin and north-tip through camera to NDC
    const ndcO = new THREE.Vector3(0, 0, 0).project(camera);
    const ndcN = northDir.clone().multiplyScalar(maxDim).project(camera);
    // Convert to screen-pixel deltas (accounts for aspect ratio)
    const sdx = (ndcN.x - ndcO.x) * width;
    const sdy = (ndcN.y - ndcO.y) * height;
    // atan2(right, up) → clockwise angle from screen-up = CSS rotate degrees
    setCompassDeg(Math.atan2(sdx, sdy) * 180 / Math.PI);

    // ── Lighting ──
    scene.add(new THREE.AmbientLight(0xffffff, 0.6));
    const dl = new THREE.DirectionalLight(0xffffff, 0.8);
    dl.position.set(d, d * 1.5, d * 0.5);
    scene.add(dl);
    const fl = new THREE.DirectionalLight(0xffffff, 0.3);
    fl.position.set(-d, d * 0.5, -d);
    scene.add(fl);

    // ── Renderer ──
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(window.devicePixelRatio);
    renderer.setClearColor(0x000000, 0);
    container.appendChild(renderer.domElement);
    renderer.render(scene, camera);

    return () => {
      renderer.dispose();
      for (const d of disposables) d.dispose();
      if (container.contains(renderer.domElement)) container.removeChild(renderer.domElement);
    };
  }, [
    geometry.vertices, geometry.faces, geometry.dims,
    geometry.source, geometry.wwr, geometry.orientation,
    geometry.sv_ratio, hasObjMesh, constraintPacket,
    viewAngle, northAngle,
  ]);

  const { L, W, H, floors } = geometry.dims;
  const wwrPct = Math.round(geometry.wwr * 100);

  return (
    <div className="w-full">
      <div className="flex items-center justify-between mb-1">
        <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
          3D Preview
          {isObj && <span className="text-green-600 ml-1">(OBJ)</span>}
        </p>
        <div className="flex gap-0.5">
          {VIEWS.map((v) => (
            <button
              key={v.id}
              onClick={() => setViewAngle(v.id)}
              className={`px-1.5 py-0.5 text-[10px] rounded font-medium transition-colors ${
                viewAngle === v.id
                  ? "bg-foreground text-background"
                  : "bg-muted text-muted-foreground hover:bg-muted/80"
              }`}
            >
              {v.label}
            </button>
          ))}
        </div>
      </div>

      {/* 3D canvas + compass overlay */}
      <div className="relative">
        <div
          ref={containerRef}
          className="w-full rounded-lg bg-slate-50 dark:bg-slate-900 overflow-hidden"
          style={{ height: 280 }}
        />
        {/* North arrow — upper-right corner, rotated to match projected north */}
        <div
          className="absolute top-2 right-2 pointer-events-none"
          style={{ width: 48, height: 48 }}
        >
          <svg viewBox="0 0 48 48" width="48" height="48">
            <g transform={`rotate(${compassDeg}, 24, 24)`}>
              {/* North half — red */}
              <polygon points="24,6 19,24 29,24" fill="#dc2626" />
              {/* South half — grey */}
              <polygon points="24,42 19,24 29,24" fill="#cbd5e1" />
              {/* Center dot */}
              <circle cx="24" cy="24" r="2" fill="#334155" />
              {/* N label — counter-rotate so text stays upright */}
              <g transform={`rotate(${-compassDeg}, 24, 4)`}>
                <text
                  x="24" y="5"
                  textAnchor="middle"
                  fontSize="9"
                  fontWeight="bold"
                  fill="#dc2626"
                  fontFamily="system-ui, sans-serif"
                >
                  N
                </text>
              </g>
            </g>
          </svg>
        </div>
      </div>

      <div className="mt-1 flex items-center justify-between text-[10px] text-muted-foreground">
        <span>{L}&times;{W}&times;{H}m</span>
        <span>{floors} floor{floors !== 1 ? "s" : ""} &middot; {wwrPct}% WWR</span>
      </div>
    </div>
  );
}
