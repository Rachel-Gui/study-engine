import { AlertCircle, Globe, Thermometer, Zap, Shield, BookOpen } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { PhaseIndicator } from "./PhaseIndicator";
import { AgentCard } from "./AgentCard";
import { ManagerCard } from "./ManagerCard";
import { TestAgentPanel } from "./TestAgentPanel";
import { PerformanceRadarChart } from "./RadarChart";
import { FacadeWWRChart } from "./FacadeWWRChart";
import { GeometryComparison } from "./GeometryComparison";
import type {
  AgentResult,
  PhaseEvent,
  GeometryPacket,
  SliderValues,
  AgentInfo,
} from "@/types";

interface ResultsPanelProps {
  phase: PhaseEvent | null;
  agentResults: AgentResult[];
  isRunning: boolean;
  error: string | null;
  currentGeometry: GeometryPacket;
  suggestedGeometry: SliderValues | null;
  constraintPacket: Record<string, number>;
  onApply: (suggested: SliderValues) => void;
  testResult: AgentResult | null;
  testLoading: boolean;
  onCloseTest: () => void;
  advocates: AgentInfo[];
}

// Site research field display config
const SITE_FIELDS: { key: string; label: string; icon: typeof Globe }[] = [
  { key: "climate_zone", label: "Climate Zone", icon: Globe },
  { key: "dominant_driver", label: "Dominant Driver", icon: Thermometer },
  { key: "design_temps", label: "Design Temperatures", icon: Thermometer },
  { key: "grid_carbon_intensity", label: "Grid Carbon Intensity", icon: Zap },
  { key: "grid_renewable_pct", label: "Renewable Mix", icon: Zap },
  { key: "energy_code", label: "Energy Code", icon: BookOpen },
  { key: "hazards", label: "Hazards", icon: Shield },
];

function SiteResearchCard({ result }: { result: AgentResult }) {
  const r = result.response as Record<string, unknown>;

  // Collect displayable fields
  const fields = SITE_FIELDS.filter((f) => r[f.key] && typeof r[f.key] === "string");
  const narrative = typeof r["narrative"] === "string" ? r["narrative"] : null;
  const siteName = typeof r["site"] === "string" ? r["site"] : null;
  const programName = typeof r["program"] === "string" ? r["program"] : null;
  const sources = Array.isArray(r["sources"]) ? (r["sources"] as string[]) : [];

  // Fallback: if none of the known fields exist, show raw text
  if (fields.length === 0 && !narrative) {
    return (
      <Card size="sm">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm">{result.agent}</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm leading-relaxed text-muted-foreground">
            {typeof r["argument"] === "string"
              ? r["argument"]
              : JSON.stringify(r, null, 2)}
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card size="sm">
      <CardHeader className="pb-2">
        <div className="flex items-center gap-2">
          <Globe className="size-4 text-blue-500" />
          <CardTitle className="text-sm">{result.agent}</CardTitle>
        </div>
        {(siteName || programName) && (
          <p className="text-xs text-muted-foreground mt-1">
            {siteName}{programName ? ` — ${programName}` : ""}
          </p>
        )}
      </CardHeader>
      <CardContent className="flex flex-col gap-3">
        {/* Narrative summary */}
        {narrative && (
          <p className="text-sm leading-relaxed">{narrative}</p>
        )}

        {/* Structured fields */}
        {fields.length > 0 && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {fields.map(({ key, label, icon: Icon }) => (
              <div
                key={key}
                className="flex items-start gap-2 rounded-md border p-2"
              >
                <Icon className="size-3.5 mt-0.5 shrink-0 text-muted-foreground" />
                <div className="flex flex-col gap-0.5 min-w-0">
                  <span className="text-[10px] font-medium uppercase tracking-wide text-muted-foreground">
                    {label}
                  </span>
                  <span className="text-xs leading-relaxed break-words">
                    {r[key] as string}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Citations */}
        {sources.length > 0 && (
          <div className="border-t pt-2 mt-1">
            <p className="text-[10px] font-medium uppercase tracking-wide text-muted-foreground mb-1.5">
              Sources
            </p>
            <ul className="flex flex-col gap-0.5">
              {sources.map((src, i) => (
                <li key={i} className="text-[11px] text-muted-foreground leading-snug flex items-start gap-1.5">
                  <BookOpen className="size-3 mt-0.5 shrink-0" />
                  <span>{src}</span>
                </li>
              ))}
            </ul>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export function ResultsPanel({
  phase,
  agentResults,
  isRunning,
  error,
  currentGeometry,
  suggestedGeometry,
  constraintPacket,
  onApply,
  testResult,
  testLoading,
  onCloseTest,
  advocates,
}: ResultsPanelProps) {
  const siteResult = agentResults.find((r) => r.type === "site_research");
  const advocateResults = agentResults.filter((r) => r.type === "advocate");
  const managerResult = agentResults.find((r) => r.type === "manager");

  const completedPhases: number[] = [];
  if (siteResult) completedPhases.push(1);
  if (advocateResults.length > 0) completedPhases.push(2);
  if (managerResult) completedPhases.push(3);

  const hasContent = agentResults.length > 0 || isRunning;
  const isSiteRunning = isRunning && !siteResult;
  const isAdvocateRunning = isRunning && siteResult && advocateResults.length < advocates.length;
  const isManagerRunning = isRunning && advocateResults.length > 0 && !managerResult;

  return (
    <div className="flex flex-col gap-5 p-4 h-full overflow-y-auto">
      {/* Test Agent Panel */}
      {(testResult || testLoading) && (
        <>
          <TestAgentPanel
            result={testResult}
            isLoading={testLoading}
            onClose={onCloseTest}
          />
          <Separator />
        </>
      )}

      {/* Error state */}
      {error && (
        <div className="flex items-start gap-2 rounded-lg border border-destructive/30 bg-destructive/5 p-3 text-sm text-destructive">
          <AlertCircle className="size-4 shrink-0 mt-0.5" />
          <span>{error}</span>
        </div>
      )}

      {/* Phase Indicator */}
      {(hasContent) && (
        <div className="flex flex-col gap-3">
          <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
            Debate Progress
          </p>
          <PhaseIndicator currentPhase={phase} completedPhases={completedPhases} />
        </div>
      )}

      {/* Site Research */}
      {(siteResult || isSiteRunning) && (
        <div className="flex flex-col gap-2">
          <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
            Phase 1 — Site Research
          </p>
          {siteResult ? (
            <SiteResearchCard result={siteResult} />
          ) : (
            <AgentCard isLoading />
          )}
        </div>
      )}

      {/* Advocates */}
      {(advocateResults.length > 0 || isAdvocateRunning) && (
        <div className="flex flex-col gap-2">
          <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
            Phase 2 — Advocate Arguments
          </p>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            {advocates.map((info) => {
              const found = advocateResults.find((r) => r.agent === info.name);
              const loading = isAdvocateRunning && !found;
              return (
                <AgentCard
                  key={info.name}
                  result={found}
                  placeholder={{ name: info.name, color: info.color }}
                  isLoading={loading}
                />
              );
            })}
          </div>
        </div>
      )}

      {/* Manager */}
      {(managerResult || isManagerRunning) && (
        <div className="flex flex-col gap-2">
          <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
            Phase 3 — Manager Decision
          </p>
          <ManagerCard
            result={managerResult}
            isLoading={isManagerRunning}
            currentGeometry={currentGeometry}
            onApply={onApply}
          />
        </div>
      )}

      {/* Analysis — shown when debate is complete */}
      {!isRunning && agentResults.length > 0 && suggestedGeometry && (
        <div className="flex flex-col gap-4">
          <Separator />
          <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
            Analysis
          </p>
          <PerformanceRadarChart
            currentGeometry={currentGeometry}
            suggestedGeometry={suggestedGeometry}
          />
          <FacadeWWRChart
            currentWWR={currentGeometry.wwr}
            constraintPacket={constraintPacket}
          />
          <GeometryComparison
            currentGeometry={currentGeometry}
            suggestedGeometry={suggestedGeometry}
          />
        </div>
      )}

      {/* Empty state */}
      {!hasContent && !error && !testResult && !testLoading && (
        <div className="flex flex-1 flex-col items-center justify-center gap-3 py-20 text-center">
          <div className="size-12 rounded-full bg-muted flex items-center justify-center text-2xl">
            🏗️
          </div>
          <div className="flex flex-col gap-1">
            <p className="font-medium text-sm">No debate yet</p>
            <p className="text-xs text-muted-foreground max-w-xs">
              Configure your building massing and click "Run Debate" to see your environmental
              advocate agents in action.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
