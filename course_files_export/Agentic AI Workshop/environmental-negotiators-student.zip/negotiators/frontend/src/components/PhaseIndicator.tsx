import { Check } from "lucide-react";
import type { PhaseEvent } from "@/types";

interface PhaseIndicatorProps {
  currentPhase: PhaseEvent | null;
  completedPhases: number[];
}

const PHASES = [
  { id: 1, label: "Site Research" },
  { id: 2, label: "Advocates Debating" },
  { id: 3, label: "Manager Resolving" },
];

export function PhaseIndicator({ currentPhase, completedPhases }: PhaseIndicatorProps) {
  return (
    <div className="flex items-center gap-0">
      {PHASES.map((phase, idx) => {
        const isCompleted = completedPhases.includes(phase.id);
        const isActive = currentPhase?.phase === phase.id;
        const isLast = idx === PHASES.length - 1;

        return (
          <div key={phase.id} className="flex items-center">
            {/* Step circle */}
            <div className="flex flex-col items-center gap-1">
              <div
                className={`flex size-7 items-center justify-center rounded-full border-2 text-xs font-bold transition-all ${
                  isCompleted
                    ? "border-teal-500 bg-teal-500 text-white"
                    : isActive
                    ? "border-primary bg-primary text-primary-foreground animate-pulse"
                    : "border-muted-foreground/30 bg-muted text-muted-foreground"
                }`}
              >
                {isCompleted ? <Check className="size-3.5" /> : phase.id}
              </div>
              <span
                className={`text-[10px] font-medium text-center max-w-[70px] leading-tight ${
                  isActive
                    ? "text-primary"
                    : isCompleted
                    ? "text-teal-600 dark:text-teal-400"
                    : "text-muted-foreground"
                }`}
              >
                {phase.label}
              </span>
            </div>

            {/* Connector line */}
            {!isLast && (
              <div
                className={`h-0.5 w-12 mx-1 mb-4 transition-colors ${
                  isCompleted ? "bg-teal-400" : "bg-muted-foreground/20"
                }`}
              />
            )}
          </div>
        );
      })}
    </div>
  );
}
