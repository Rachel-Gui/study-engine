import { X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { AgentCard } from "./AgentCard";
import type { AgentResult } from "@/types";

interface TestAgentPanelProps {
  result: AgentResult | null;
  isLoading: boolean;
  onClose: () => void;
}

export function TestAgentPanel({ result, isLoading, onClose }: TestAgentPanelProps) {
  if (!result && !isLoading) return null;

  return (
    <div className="flex flex-col gap-2">
      <div className="flex items-center justify-between">
        <span className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
          Test Result
        </span>
        <Button
          variant="ghost"
          size="icon-xs"
          onClick={onClose}
          aria-label="Close test result"
        >
          <X className="size-3.5" />
        </Button>
      </div>
      <AgentCard result={result ?? undefined} isLoading={isLoading} />
    </div>
  );
}
