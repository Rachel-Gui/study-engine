import { useState } from "react";
import { Loader2, AlertCircle, CheckCircle2 } from "lucide-react";
import { uploadObj } from "@/lib/api";
import type { GeometryPacket } from "@/types";

interface ObjUploadProps {
  onUpload: (geometry: GeometryPacket) => void;
}

export function ObjUpload({ onUpload }: ObjUploadProps) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [fileName, setFileName] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);

  async function handleFile(file: File) {
    if (!file.name.endsWith(".obj")) {
      setError("Only .obj files are supported.");
      return;
    }
    setError(null);
    setLoading(true);
    setFileName(file.name);
    try {
      const geometry = await uploadObj(file);
      if ("error" in geometry) {
        setError(String((geometry as Record<string, unknown>).error));
        setFileName(null);
      } else {
        onUpload(geometry);
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : "Upload failed.");
      setFileName(null);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="flex flex-col gap-2">
      {/* Drop zone */}
      <div
        onDrop={(e) => {
          e.preventDefault();
          setIsDragging(false);
          const file = e.dataTransfer.files?.[0];
          if (file) handleFile(file);
        }}
        onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
        onDragLeave={() => setIsDragging(false)}
        className={`relative flex flex-col items-center justify-center gap-2 rounded-lg border-2 border-dashed p-4 text-center transition-colors ${
          isDragging
            ? "border-primary bg-primary/5"
            : "border-border hover:border-primary/50 hover:bg-muted/50"
        } ${loading ? "opacity-60" : ""}`}
      >
        {loading ? (
          <Loader2 className="size-5 animate-spin text-muted-foreground" />
        ) : fileName ? (
          <CheckCircle2 className="size-5 text-green-500" />
        ) : null}
        <span className="text-xs text-muted-foreground">
          {loading ? "Parsing..." : fileName ? fileName : "Drop .obj file here"}
        </span>
      </div>

      {/* Separate native file input — always works for click */}
      <input
        type="file"
        accept=".obj"
        disabled={loading}
        className="text-xs file:mr-2 file:py-1 file:px-3 file:rounded-md file:border-0 file:text-xs file:font-medium file:bg-primary file:text-primary-foreground file:cursor-pointer hover:file:bg-primary/90 cursor-pointer"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) handleFile(file);
          e.target.value = "";
        }}
      />

      {error && (
        <div className="flex items-center gap-1.5 text-xs text-destructive">
          <AlertCircle className="size-3.5 shrink-0" />
          <span>{error}</span>
        </div>
      )}
    </div>
  );
}
