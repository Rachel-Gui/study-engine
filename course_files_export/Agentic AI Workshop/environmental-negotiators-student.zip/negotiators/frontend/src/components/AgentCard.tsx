import React from "react";
import { Globe, Sun, Leaf, Zap, Users, Bot } from "lucide-react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import type { AgentResult, AdvocateResponse } from "@/types";

interface AgentCardProps {
  result?: AgentResult;
  placeholder?: { name: string; color: string };
  isLoading?: boolean;
}

const ICON_MAP: Record<string, React.ComponentType<{ className?: string }>> = {
  globe: Globe,
  sun: Sun,
  leaf: Leaf,
  zap: Zap,
  users: Users,
  bot: Bot,
};

function getIcon(iconName: string): React.ComponentType<React.SVGProps<SVGSVGElement>> {
  return (ICON_MAP[iconName.toLowerCase()] ?? Bot) as React.ComponentType<React.SVGProps<SVGSVGElement>>;
}

function isAdvocateResponse(r: unknown): r is AdvocateResponse {
  return (
    typeof r === "object" &&
    r !== null &&
    "argument" in r &&
    "critical_finding" in r
  );
}

export function AgentCard({ result, placeholder, isLoading }: AgentCardProps) {
  const name = result?.agent ?? placeholder?.name ?? "Agent";
  const color = result?.color ?? placeholder?.color ?? "#6b7280";
  const iconName = result?.icon ?? "bot";
  const Icon = getIcon(iconName);

  if (isLoading) {
    return (
      <Card className="relative overflow-hidden">
        <div
          className="absolute top-0 left-0 right-0 h-1"
          style={{ backgroundColor: color }}
        />
        <div className="absolute inset-0 -translate-x-full animate-[shimmer_1.5s_infinite] bg-gradient-to-r from-transparent via-white/20 to-transparent" />
        <CardHeader className="pb-2 pt-5">
          <div className="flex items-center gap-2">
            <div className="size-5 rounded-full bg-muted animate-pulse" />
            <div className="h-4 w-24 rounded bg-muted animate-pulse" />
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col gap-2">
            <div className="h-3 w-full rounded bg-muted animate-pulse" />
            <div className="h-3 w-3/4 rounded bg-muted animate-pulse" />
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="relative overflow-hidden">
      {/* Colored top border */}
      <div
        className="absolute top-0 left-0 right-0 h-1"
        style={{ backgroundColor: color }}
      />
      <CardHeader className="pb-2 pt-5">
        <CardTitle className="flex items-center gap-2 text-sm">
          <span style={{ color }}><Icon className="size-4" /></span>
          <span>{name}</span>
          {result && (
            <Badge
              variant={result.status === "success" ? "secondary" : "destructive"}
              className="ml-auto text-[10px]"
            >
              {result.status}
            </Badge>
          )}
        </CardTitle>
        {result?.role && (
          <p className="text-xs text-muted-foreground">{result.role}</p>
        )}
      </CardHeader>

      {result && isAdvocateResponse(result.response) && (
        <CardContent className="flex flex-col gap-3">
          {/* Main argument */}
          {result.response.argument && (
            <p className="text-sm leading-relaxed">{result.response.argument}</p>
          )}

          {/* Critical finding */}
          {result.response.critical_finding && (
            <div
              className="rounded-md border-l-4 bg-amber-50 p-2.5 text-xs leading-relaxed dark:bg-amber-950/20"
              style={{ borderLeftColor: color }}
            >
              <span className="font-semibold text-amber-800 dark:text-amber-300">
                Key finding:{" "}
              </span>
              <span className="text-amber-900 dark:text-amber-200">
                {result.response.critical_finding}
              </span>
            </div>
          )}

          {/* Proposed changes */}
          {result.response.proposed_changes && (
            <div className="flex flex-col gap-1">
              <span className="text-xs font-medium text-muted-foreground">Proposed changes</span>
              <p className="text-xs text-foreground/80 leading-relaxed">
                {result.response.proposed_changes}
              </p>
            </div>
          )}

          {/* Sources */}
          {result.response.sources && (Array.isArray(result.response.sources) ? result.response.sources : [result.response.sources]).length > 0 && (
            <div className="flex flex-col gap-1 pt-1 border-t border-dashed">
              <span className="text-[10px] font-medium text-muted-foreground uppercase tracking-wide">Sources</span>
              <ul className="flex flex-col gap-0.5">
                {(Array.isArray(result.response.sources) ? result.response.sources : [result.response.sources]).map((s, i) => (
                  <li key={i} className="text-[10px] text-muted-foreground italic">
                    {String(s)}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </CardContent>
      )}

      {result && !isAdvocateResponse(result.response) && result.response && (
        <CardContent>
          <pre className="text-xs whitespace-pre-wrap text-muted-foreground overflow-auto max-h-40">
            {JSON.stringify(result.response, null, 2)}
          </pre>
        </CardContent>
      )}

      {!result && !isLoading && placeholder && (
        <CardContent>
          <p className="text-xs text-muted-foreground italic">Waiting for debate to start…</p>
        </CardContent>
      )}
    </Card>
  );
}
