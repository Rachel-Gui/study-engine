import {
  Radar,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  ResponsiveContainer,
  Legend,
} from "recharts";
import { computeGeometry } from "@/lib/geometry";
import type { GeometryPacket, SliderValues } from "@/types";

interface RadarChartProps {
  currentGeometry: GeometryPacket;
  suggestedGeometry: SliderValues | null;
}

// Normalize a value from [min, max] to [0, 100]
function normalize(value: number, min: number, max: number): number {
  if (max === min) return 50;
  return Math.round(((value - min) / (max - min)) * 100);
}

export function PerformanceRadarChart({
  currentGeometry,
  suggestedGeometry,
}: RadarChartProps) {
  if (!suggestedGeometry) return null;

  const suggested = computeGeometry(suggestedGeometry);

  // Ranges for normalization — lower is better for sv_ratio/wwr, higher is better for south_bias
  const axes = [
    {
      label: "S/V Ratio",
      // Lower sv_ratio is better (more compact). Invert so high score = better.
      currentRaw: currentGeometry.sv_ratio,
      suggestedRaw: suggested.sv_ratio,
      min: 0.1,
      max: 0.8,
      invert: true,
    },
    {
      label: "WWR",
      currentRaw: currentGeometry.wwr,
      suggestedRaw: suggested.wwr,
      min: 0.1,
      max: 0.9,
      invert: false,
    },
    {
      label: "South Exposure",
      currentRaw: currentGeometry.south_bias,
      suggestedRaw: suggested.south_bias,
      min: 0,
      max: 0.6,
      invert: false,
    },
    {
      label: "Form Factor",
      // Lower form factor = more efficient. Invert.
      currentRaw: currentGeometry.form_factor,
      suggestedRaw: suggested.form_factor,
      min: 0.1,
      max: 2.0,
      invert: true,
    },
    {
      label: "Volume",
      currentRaw: currentGeometry.volume,
      suggestedRaw: suggested.volume,
      min: 1000,
      max: 50000,
      invert: false,
    },
  ];

  const data = axes.map(({ label, currentRaw, suggestedRaw, min, max, invert }) => {
    let cur = normalize(currentRaw, min, max);
    let sug = normalize(suggestedRaw, min, max);
    if (invert) {
      cur = 100 - cur;
      sug = 100 - sug;
    }
    return { metric: label, Current: cur, Suggested: sug };
  });

  return (
    <div className="w-full">
      <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
        Performance Radar
      </p>
      <ResponsiveContainer width="100%" height={280}>
        <RadarChart data={data} margin={{ top: 10, right: 30, bottom: 10, left: 30 }}>
          <PolarGrid stroke="#334155" strokeOpacity={0.3} />
          <PolarAngleAxis
            dataKey="metric"
            tick={{ fill: "#94a3b8", fontSize: 11 }}
          />
          <Radar
            name="Current"
            dataKey="Current"
            stroke="#3b82f6"
            fill="#3b82f6"
            fillOpacity={0.2}
            strokeWidth={2}
          />
          <Radar
            name="Suggested"
            dataKey="Suggested"
            stroke="#22c55e"
            fill="#22c55e"
            fillOpacity={0.2}
            strokeWidth={2}
          />
          <Legend
            wrapperStyle={{ fontSize: 11, color: "#94a3b8" }}
          />
        </RadarChart>
      </ResponsiveContainer>
    </div>
  );
}
