import { useState, useMemo, useEffect, useCallback } from "react";
import { InputPanel } from "@/components/InputPanel";
import { ResultsPanel } from "@/components/ResultsPanel";
import { useSSE } from "@/hooks/useSSE";
import { fetchAgents, testAgent } from "@/lib/api";
import { computeGeometry } from "@/lib/geometry";
import type { SliderValues, GeometryPacket, AgentInfo, AgentResult, PriorityLevel } from "@/types";

const DEFAULT_SLIDERS: SliderValues = {
  L: 42,
  W: 18,
  H: 28,
  floors: 7,
  wwr: 0.45,
  orientation: 180,
  northAngle: 0,
};

export default function App() {
  // Core state
  const [sliders, setSliders] = useState<SliderValues>(DEFAULT_SLIDERS);
  const [site, setSite] = useState("200 University Ave W, Waterloo, Ontario");
  const [program, setProgram] = useState("Higher Education");
  const [agents, setAgents] = useState<AgentInfo[]>([]);
  const [testResult, setTestResult] = useState<AgentResult | null>(null);
  const [testLoading, setTestLoading] = useState(false);
  const [appliedBanner, setAppliedBanner] = useState(false);
  const [objGeometry, setObjGeometry] = useState<GeometryPacket | null>(null);
  const [priorities, setPriorities] = useState<Record<string, PriorityLevel>>({});

  // Derived state
  const geometry = useMemo(() => computeGeometry(sliders), [sliders]);
  // Merge slider-adjustable values into OBJ geometry so ALL sliders work
  const activeGeometry = useMemo(() => {
    if (!objGeometry) return geometry;
    const { L, W, H, floors, wwr, orientation } = sliders;
    const origL = objGeometry.dims.L;
    const origW = objGeometry.dims.W;
    const origH = objGeometry.dims.H;

    // Scale factors relative to original OBJ dimensions
    const sx = origL > 0 ? L / origL : 1;
    const sy = origH > 0 ? H / origH : 1;
    const sz = origW > 0 ? W / origW : 1;

    // Scale vertices so 3D preview renders at the new size
    const scaledVerts = objGeometry.vertices?.map(v => [v[0] * sx, v[1] * sy, v[2] * sz]);

    // Scale facade areas: N/S walls span X·Y, E/W walls span Z·Y
    const origFA = objGeometry.facade_areas;
    const scaledFA = {
      N: origFA.N * sx * sy,
      S: origFA.S * sx * sy,
      E: origFA.E * sz * sy,
      W: origFA.W * sz * sy,
    };

    // Remap facade areas when orientation changes (OBJ default orientation = 180)
    const rotSteps = (((Math.round((orientation - 180) / 90)) % 4) + 4) % 4;
    const dirs = ["N", "E", "S", "W"] as const;
    const finalFacades = { N: 0, E: 0, S: 0, W: 0 };
    for (let i = 0; i < 4; i++) {
      finalFacades[dirs[(i + rotSteps) % 4]] = scaledFA[dirs[i]];
    }

    const totalWall = Object.values(finalFacades).reduce((a, b) => a + b, 0);
    const southBias = totalWall > 0 ? Math.round((finalFacades.S / totalWall) * 100) / 100 : 0;
    const scaledRoof = objGeometry.roof_area * sx * sz;
    const scaledVolume = objGeometry.volume * sx * sy * sz;
    const floorArea = scaledRoof * floors;
    const envelope = totalWall + scaledRoof;
    const svRatio = scaledVolume > 0 ? Math.round((envelope / scaledVolume) * 100) / 100 : 0;
    const formFactor = floorArea > 0 ? Math.round((envelope / floorArea) * 100) / 100 : 0;

    const dominant = (Object.entries(finalFacades) as [string, number][])
      .reduce((a, b) => (b[1] > a[1] ? b : a))[0];

    return {
      ...objGeometry,
      dims: { L, W, H, floors },
      vertices: scaledVerts,
      facade_areas: finalFacades,
      roof_area: scaledRoof,
      floor_area: floorArea,
      volume: scaledVolume,
      sv_ratio: svRatio,
      form_factor: formFactor,
      south_bias: southBias,
      wwr,
      orientation,
      dominant_orientation: dominant,
    };
  }, [objGeometry, geometry, sliders]);

  // SSE hook
  const sse = useSSE();

  // Fetch agents on mount, refresh every 5 seconds
  useEffect(() => {
    let cancelled = false;

    const load = async () => {
      try {
        const data = await fetchAgents();
        if (!cancelled) setAgents(data);
      } catch {
        // silently ignore fetch errors during polling
      }
    };

    load();
    const interval = setInterval(load, 5000);
    return () => {
      cancelled = true;
      clearInterval(interval);
    };
  }, []);

  // Handlers
  const handleTestAgent = useCallback(
    async (name: string) => {
      setTestLoading(true);
      setTestResult(null);
      try {
        const result = await testAgent(name, activeGeometry, site, program);
        setTestResult(result);
      } catch (err) {
        setTestResult({
          agent: name,
          role: "",
          color: "#ef4444",
          icon: "⚠️",
          status: "error",
          type: "advocate",
          response: { error: (err as Error).message },
        });
      } finally {
        setTestLoading(false);
      }
    },
    [activeGeometry, site, program]
  );

  const handleRunDebate = useCallback((quick: boolean) => {
    sse.startAnalysis(activeGeometry, site, program, quick, priorities);
  }, [sse, activeGeometry, site, program, priorities]);

  const handleStopDebate = useCallback(() => {
    sse.stop();
  }, [sse]);

  const handleApply = useCallback((suggested: SliderValues) => {
    setSliders(prev => ({ ...suggested, northAngle: suggested.northAngle ?? prev.northAngle }));
    setObjGeometry(null);
    setAppliedBanner(true);
    setTimeout(() => setAppliedBanner(false), 4000);
  }, []);

  const handleObjUpload = useCallback((g: GeometryPacket) => {
    setObjGeometry(g);
    setSliders(prev => ({
      L: g.dims.L,
      W: g.dims.W,
      H: g.dims.H,
      floors: g.dims.floors,
      wwr: g.wwr,
      orientation: g.orientation,
      northAngle: prev.northAngle,
    }));
  }, []);

  const advocateAgents = agents.filter((a) => a.type === "advocate");

  return (
    <div className="flex flex-col h-screen bg-background text-foreground">
      {/* Header */}
      <header className="flex items-center justify-between px-5 py-3 border-b shrink-0">
        <div className="flex flex-col">
          <h1 className="text-base font-semibold leading-tight">
            Environmental Negotiators
          </h1>
          <p className="text-xs text-muted-foreground">
            AI-powered building performance debate
          </p>
        </div>
        <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
          <span className={`size-2 rounded-full ${agents.length > 0 ? "bg-green-500" : "bg-muted"}`} />
          {agents.length} agent{agents.length !== 1 ? "s" : ""} online
        </div>
      </header>

      {/* Applied banner */}
      {appliedBanner && (
        <div className="bg-green-600 text-white text-sm text-center py-2 px-4 shrink-0">
          Geometry applied — sliders updated from manager suggestion.
        </div>
      )}

      {/* Main content */}
      <div className="flex flex-1 min-h-0">
        {/* Left panel — fixed 380px */}
        <div className="w-[380px] shrink-0 border-r overflow-hidden">
          <InputPanel
            sliders={sliders}
            onSlidersChange={setSliders}
            geometry={activeGeometry}
            onObjUpload={handleObjUpload}
            site={site}
            onSiteChange={setSite}
            program={program}
            onProgramChange={setProgram}
            agents={agents}
            onTestAgent={handleTestAgent}
            onRunDebate={handleRunDebate}
            onStopDebate={handleStopDebate}
            isRunning={sse.isRunning}
            constraints={sse.constraintPacket}
            priorities={priorities}
            onPrioritiesChange={setPriorities}
          />
        </div>

        {/* Right panel — flex-1 */}
        <div className="flex-1 overflow-hidden">
          <ResultsPanel
            phase={sse.phase}
            agentResults={sse.agentResults}
            isRunning={sse.isRunning}
            error={sse.error}
            currentGeometry={activeGeometry}
            suggestedGeometry={sse.suggestedGeometry}
            constraintPacket={sse.constraintPacket}
            onApply={handleApply}
            testResult={testResult}
            testLoading={testLoading}
            onCloseTest={() => setTestResult(null)}
            advocates={advocateAgents}
          />
        </div>
      </div>
    </div>
  );
}
