import type { GeometryPacket, SliderValues, FacadeAreas } from "../types";

export function computeGeometry(sliders: SliderValues): GeometryPacket {
  const { L, W, H, floors, wwr, orientation, northAngle: _north } = sliders;
  void _north; // northAngle is a view param — not used in geometric calculations

  const frontArea = L * H;
  const backArea = L * H;
  const sideArea = W * H;

  const facadeAreas = orientFacades(frontArea, backArea, sideArea, orientation);

  const roofArea = L * W;
  const floorArea = L * W * floors;
  const volume = L * W * H;

  const totalWall = Object.values(facadeAreas).reduce((a, b) => a + b, 0);
  const envelopeArea = totalWall + roofArea;

  const svRatio = volume > 0 ? Math.round((envelopeArea / volume) * 100) / 100 : 0;
  const formFactor = floorArea > 0 ? Math.round((envelopeArea / floorArea) * 100) / 100 : 0;
  const southBias = totalWall > 0 ? Math.round((facadeAreas.S / totalWall) * 100) / 100 : 0;

  const dominant = (Object.entries(facadeAreas) as [string, number][])
    .reduce((a, b) => (b[1] > a[1] ? b : a))[0];

  const dirNames: Record<string, string> = { N: "north", E: "east", S: "south", W: "west" };
  const dirs = ["N", "E", "S", "W"];
  const frontIdx = Math.round(orientation / 90) % 4;
  const frontDir = dirNames[dirs[frontIdx]];

  const narrative = [
    `${L}\u00d7${W}\u00d7${H}m, ${floors}-story building.`,
    `Main facade faces ${frontDir}.`,
    `S/V ratio: ${svRatio}.`,
    `Window-to-wall ratio: ${Math.round(wwr * 100)}%.`,
    `South-facing facades make up ${Math.round(southBias * 100)}% of total wall area.`,
    `Largest facade faces ${dirNames[dominant]} (${facadeAreas[dominant as keyof FacadeAreas].toFixed(0)} m\u00b2).`,
  ].join(" ");

  return {
    source: "sliders",
    dims: { L, W, H, floors },
    facade_areas: facadeAreas,
    roof_area: roofArea,
    floor_area: floorArea,
    volume,
    sv_ratio: svRatio,
    form_factor: formFactor,
    south_bias: southBias,
    wwr,
    orientation,
    dominant_orientation: dominant,
    narrative,
  };
}

function orientFacades(
  front: number, back: number, side: number, orientation: number
): FacadeAreas {
  const dirs: ("N" | "E" | "S" | "W")[] = ["N", "E", "S", "W"];
  const idx = Math.round(orientation / 90) % 4;
  const result: FacadeAreas = { N: 0, E: 0, S: 0, W: 0 };
  result[dirs[idx]] = front;
  result[dirs[(idx + 2) % 4]] = back;
  result[dirs[(idx + 1) % 4]] = side;
  result[dirs[(idx + 3) % 4]] = side;
  return result;
}
