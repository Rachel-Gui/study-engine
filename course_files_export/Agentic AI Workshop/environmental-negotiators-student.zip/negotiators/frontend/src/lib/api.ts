import type { AgentInfo, AgentResult, GeometryPacket } from "../types";

const API_BASE = "/api";

export async function fetchAgents(): Promise<AgentInfo[]> {
  const res = await fetch(`${API_BASE}/agents`);
  const data = await res.json();
  return data.agents ?? [];
}

export async function testAgent(
  agentName: string,
  geometry: GeometryPacket,
  site: string,
  program: string
): Promise<AgentResult> {
  const res = await fetch(`${API_BASE}/test-agent`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ agent_name: agentName, geometry, site, program }),
  });
  return res.json();
}

export async function uploadObj(file: File): Promise<GeometryPacket> {
  const formData = new FormData();
  formData.append("file", file);
  const res = await fetch(`${API_BASE}/upload-obj`, {
    method: "POST",
    body: formData,
  });
  return res.json();
}
