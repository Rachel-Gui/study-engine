import { useState, useCallback, useRef } from "react";
import type { AgentResult, PhaseEvent, SliderValues, GeometryPacket, PriorityLevel } from "../types";

export interface SSEState {
  phase: PhaseEvent | null;
  agentResults: AgentResult[];
  constraintPacket: Record<string, number>;
  suggestedGeometry: SliderValues | null;
  isRunning: boolean;
  error: string | null;
}

export function useSSE() {
  const [state, setState] = useState<SSEState>({
    phase: null,
    agentResults: [],
    constraintPacket: {},
    suggestedGeometry: null,
    isRunning: false,
    error: null,
  });

  const abortRef = useRef<AbortController | null>(null);

  const startAnalysis = useCallback(
    async (geometry: GeometryPacket, site: string, program: string, quick: boolean = false, priorities: Record<string, PriorityLevel> = {}) => {
      setState({
        phase: null,
        agentResults: [],
        constraintPacket: {},
        suggestedGeometry: null,
        isRunning: true,
        error: null,
      });

      abortRef.current?.abort();
      const controller = new AbortController();
      abortRef.current = controller;

      try {
        const response = await fetch("/api/analyze", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ geometry, site, program, quick, priorities }),
          signal: controller.signal,
        });

        if (!response.ok) {
          const body = await response.json().catch(() => null);
          throw new Error(body?.error ?? `HTTP ${response.status}`);
        }

        const reader = response.body?.getReader();
        if (!reader) throw new Error("No response body");

        const decoder = new TextDecoder();
        let buffer = "";

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          buffer += decoder.decode(value, { stream: true });

          const lines = buffer.split("\n");
          buffer = lines.pop() ?? "";

          let currentEvent = "";
          for (const line of lines) {
            if (line.startsWith("event: ")) {
              currentEvent = line.slice(7).trim();
            } else if (line.startsWith("data: ")) {
              const data = JSON.parse(line.slice(6));

              if (currentEvent === "phase") {
                setState((prev) => ({ ...prev, phase: data }));
              } else if (currentEvent === "agent_result") {
                setState((prev) => ({
                  ...prev,
                  agentResults: [...prev.agentResults, data],
                }));
              } else if (currentEvent === "done") {
                setState((prev) => ({
                  ...prev,
                  constraintPacket: data.constraint_packet ?? {},
                  suggestedGeometry: data.suggested_geometry ?? null,
                  isRunning: false,
                }));
              }
            }
          }
        }

        setState((prev) => (prev.isRunning ? { ...prev, isRunning: false } : prev));
      } catch (err) {
        if ((err as Error).name !== "AbortError") {
          setState((prev) => ({
            ...prev,
            isRunning: false,
            error: (err as Error).message,
          }));
        }
      }
    },
    []
  );

  const stop = useCallback(() => {
    abortRef.current?.abort();
    abortRef.current = null;
    setState((prev) => ({ ...prev, isRunning: false, error: null }));
  }, []);

  const reset = useCallback(() => {
    abortRef.current?.abort();
    abortRef.current = null;
    setState({
      phase: null,
      agentResults: [],
      constraintPacket: {},
      suggestedGeometry: null,
      isRunning: false,
      error: null,
    });
  }, []);

  return { ...state, startAnalysis, stop, reset };
}
