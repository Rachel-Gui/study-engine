export interface Dims {
  L: number;
  W: number;
  H: number;
  floors: number;
}

export interface FacadeAreas {
  N: number;
  S: number;
  E: number;
  W: number;
}

export interface GeometryPacket {
  source: "sliders" | "obj";
  dims: Dims;
  facade_areas: FacadeAreas;
  roof_area: number;
  floor_area: number;
  volume: number;
  sv_ratio: number;
  form_factor: number;
  south_bias: number;
  wwr: number;
  orientation: number;
  dominant_orientation: string;
  narrative: string;
  vertices?: number[][];
  faces?: number[][];
}

export interface SliderValues {
  L: number;
  W: number;
  H: number;
  floors: number;
  wwr: number;
  orientation: number;
  northAngle: number;
}

export type PriorityLevel = "High" | "Medium" | "Low";

export interface AgentInfo {
  name: string;
  role: string;
  instructions: string;
  color: string;
  icon: string;
  type: "site_research" | "advocate" | "manager";
}

export interface AdvocateResponse {
  argument: string;
  critical_finding: string;
  proposed_changes: string;
  geometry_suggestion?: Partial<SliderValues>;
  sources?: string[];
}

export interface Conflict {
  issue: string;
  positions: Record<string, string>;
  resolution: string;
}

export interface ManagerResponse {
  agreements: string[];
  conflicts: Conflict[];
  final_verdict: string;
  suggested_geometry: SliderValues;
  constraint_packet: Record<string, number>;
}

export interface AgentResult {
  agent: string;
  role: string;
  color: string;
  icon: string;
  status: "success" | "error";
  type: "site_research" | "advocate" | "manager";
  response: AdvocateResponse | ManagerResponse | Record<string, unknown>;
}

export interface PhaseEvent {
  phase: number;
  label: string;
}

export type SSEEvent =
  | { event: "phase"; data: PhaseEvent }
  | { event: "agent_result"; data: AgentResult }
  | { event: "done"; data: { constraint_packet: Record<string, number>; suggested_geometry: SliderValues } };
