# Workshop Setup — Environmental Negotiators

## Requirements

| Requirement | Minimum |
|---|---|
| **RAM** | 8 GB (16 GB recommended) |
| **Disk space** | ~2 GB free (for tools + model cache) |
| **OS** | Windows 10+, macOS 12+, or Ubuntu 20.04+ |
| **Internet** | Required throughout the workshop (the AI model runs in the cloud via Ollama) |

**Software you'll install:** Ollama, Python 3.10+, Node.js 18+

---

## Overview

You will create AI agents that debate building design decisions. Each agent argues from a single environmental perspective — energy, daylight, carbon, resilience, etc. A manager agent resolves the conflicts and proposes a final design.

You work in one file (`negotiators.py`) using plain English instructions. No coding experience needed.

### What You'll Learn

- What an AI agent actually is — a structured prompt, not a black box
- How to write effective prompts — specific, opinionated, and grounded in data
- How multi-agent debate surfaces real design tradeoffs
- How AI output connects to parametric design decisions

---

## Pre-Workshop Setup

Complete these steps **before** the workshop.

### 1. Unzip the Workshop Folder

You should have received a `.zip` file. Unzip it and open a terminal inside the `negotiators` folder.

**Windows (PowerShell):**
```powershell
cd C:\path\to\negotiators
```

**macOS / Linux:**
```bash
cd /path/to/negotiators
```

> Use this folder as your working directory for all remaining steps.

### 2. Install Ollama

Download from [ollama.com](https://ollama.com) and install it.

**Make sure Ollama is updated to the latest version** — cloud model support requires a recent release. If you already have Ollama, update it before continuing.

After installing, confirm it's running — you should see the Ollama icon in your system tray (Windows) or menu bar (macOS).

### 3. Sign in to Ollama

Cloud models require an Ollama account. Run:

```bash
ollama signin
```

This opens a browser for you to sign in or create a free account. You only need to do this once.

### 4. Pull the Model

```bash
ollama pull glm-5.1:cloud
```

This downloads the model configuration (small). The actual inference runs in the cloud, so no large download is needed.

### 5. Install Python 3.10+

Check your version:

**Windows:**
```powershell
python --version
```

**macOS / Linux:**
```bash
python3 --version
```

If you don't have Python 3.10 or later, install from [python.org](https://python.org).

### 6. Install Python Dependencies

**Windows:**
```powershell
python -m pip install -r requirements.txt
```

**macOS / Linux:**
```bash
pip3 install -r requirements.txt
```

### 7. Install a Text Editor

You will need an editor that shows line numbers and handles Python indentation. **VS Code** is recommended — download from [code.visualstudio.com](https://code.visualstudio.com). Any code editor works (Sublime Text, Atom, etc.) but avoid plain Notepad.

### 8. Install Node.js 18+

Check your version:

```bash
node --version
```

If you don't have Node.js 18 or later, install from [nodejs.org](https://nodejs.org).

### 9. Install Frontend Dependencies

```bash
cd frontend
npm install
cd ..
```

### 10. Verify Everything Works

**Windows:**
```powershell
python verify.py
```

**macOS / Linux:**
```bash
python3 verify.py
```

You should see all checks pass. The "Backend reachable" check will fail if you haven't started the server yet — that's OK.

---

## During the Workshop

You'll need **4 things open**:

1. A **text editor** (VS Code recommended) with `negotiators.py` open
2. A **terminal** running the backend
3. A **terminal** running the frontend
4. A **browser** at `http://localhost:5173`

### Starting the Servers

**Backend** (terminal 1):

Windows:
```powershell
python -m uvicorn backend.main:app --reload --port 8002
```

macOS / Linux:
```bash
python3 -m uvicorn backend.main:app --reload --port 8002
```

**Frontend** (terminal 2):
```bash
cd frontend
npm run dev
```

Then open **http://localhost:5173** in your browser.

> **Both servers stay running for the entire workshop.** You start them once and leave them. When you save `negotiators.py`, the backend automatically reloads and the dashboard picks up your changes within a few seconds — you'll see the agent count update in the header. You do **not** need to restart anything or refresh the browser.

### The Dashboard

The left panel is your building input. The right panel shows debate results.

**Left panel (inputs):**

| Control | What it does |
|---|---|
| **3D Preview** | Live isometric view of your building — updates as you move sliders |
| **Site Address** | Location for your building (agents use this for climate data) |
| **Building Program** | Type of building: Office, Residential, Healthcare, etc. |
| **Massing Sliders** | Set the building geometry the agents will analyze: |
| &nbsp;&nbsp;&nbsp;&nbsp;Length / Width / Height | Building dimensions in metres |
| &nbsp;&nbsp;&nbsp;&nbsp;Floors | Number of storeys |
| &nbsp;&nbsp;&nbsp;&nbsp;Glazing (WWR) | Window-to-wall ratio (how much of the wall is glass) |
| &nbsp;&nbsp;&nbsp;&nbsp;Orientation | Which direction the front facade faces (0° = North, 180° = South) |
| **Import Geometry** | Upload an OBJ file to replace the default box geometry with a custom massing. The L/W/H sliders don't apply to uploaded geometry — metrics are computed directly from the mesh. |
| **Advocate Priorities** | Set High / Medium / Low priority per advocate — the manager weighs higher-priority perspectives more heavily when resolving conflicts |
| **Test Single Agent** | Run one agent by itself to check its output before running the full debate |
| **Quick / Full Debate** | Quick uses pre-loaded site data (faster). Full has the AI research the site first. |

**Right panel (results):** agent cards appear here as the debate runs. The manager card appears last with the final resolution.

---

## Workshop Exercise

---

### Step 1 — See What an Agent Is

Open `agents.py`. This is the entire Agent class:

```python
class Agent:
    def __init__(self, name, role, instructions, color="#666", icon="bot"):
```

Five fields. An agent is not a black box — it's a **name**, a **role**, and **instructions** that get sent to an AI model.

---

### Step 2 — See How an Agent Becomes an API Call

Open `backend/runner.py` and look at `build_prompt()`. This is where your words become an actual AI request:

```
system prompt  =  your agent's instructions  +  output schema
user message   =  building geometry data     +  climate data
```

Then look at `run_agent()`:

```python
response = await _async_client.chat(model=MODEL, messages=messages)
```

That's the entire AI call. Your instructions become the **system prompt**, the building data becomes the **user message**, and the model returns JSON. This is the same pattern used in every agent framework — OpenAI, Anthropic, LangChain, CrewAI — the wrappers differ, but it's always: **system prompt + user context → model → structured response**.

---

### Step 3 — See How Agents Are Orchestrated

Open `backend/pipeline.py`. The pipeline runs in three phases:

```
Phase 1:  Site Researcher runs alone        (sequential — others need its data)
Phase 2:  Your advocates run in parallel     (independent — they don't see each other)
Phase 3:  Manager runs last                  (sequential — it needs all advocate results)
```

This is a common orchestration pattern: **gather context → parallel independent work → synthesize**. The output of each phase feeds into the next. When you build your own agent systems, you'll make the same design decisions: what runs first, what can be parallelized, and what needs to wait.

---

### Step 4 — Read the Example Agent

Open `negotiators.py`. The **Site Researcher** is already written. Read its `instructions` — notice how it:
- Defines a clear **scope** ("research and report")
- Lists **specific things** to look for (climate zone, grid carbon intensity, hazards)
- Tells the AI **how to respond** ("Be specific... use real data, not generalities")

This is what a good agent prompt looks like. Vague instructions produce vague results — in this system and in any agent system you build.

---

### Step 5 — Create Your First Advocate

In `negotiators.py`, find the `advocates = []` list. Add your first agent. Pick **one environmental perspective** and write an agent that argues for it.

Here is a complete advocate you can use as a starting point:

```python
advocates = [
    Agent(
        name="Energy Efficiency Advocate",
        role="Argue for minimal operational energy use",
        instructions="""You are the energy efficiency advocate. Your ONLY concern
        is reducing the building's operational energy consumption.

        Look at the geometry and climate data provided. Argue from these angles:
        - Is the surface-to-volume ratio efficient for the climate?
        - Is the WWR too high, causing excessive heat loss or cooling load?
        - Does the orientation take advantage of passive solar heating?
        - Would a more compact form reduce envelope losses?

        Reference specific numbers from the data. Take a strong position.
        If the WWR is too high for a heating-dominated climate, say so and
        propose a specific lower number.

        You may NOT consider daylight quality or embodied carbon. Those are
        other advocates' concerns. Focus only on energy.""",
        color="#3B82F6",
        icon="zap",
    ),
]
```

**`color` and `icon` reference:**
- `color` — a hex color code for the agent's card (e.g. `"#3B82F6"`). Search "hex color picker" online to choose one.
- `icon` — one of: `globe`, `sun`, `leaf`, `zap`, `users`, `bot`

**Why these instructions work — and why this matters beyond this workshop:**
- **"Your ONLY concern is..."** — constrains the agent's scope. In any agent system, unfocused agents produce generic output.
- **Bullet-point angles** — gives the model a checklist. Without structure, it rambles.
- **"propose a specific lower number"** — forces concrete output instead of hedging. This is the difference between a useful agent and a chatbot.
- **"You may NOT consider..."** — creates boundaries. In multi-agent systems, overlap between agents weakens the debate.

---

### Step 6 — Create a Second Advocate That Disagrees

Add a second agent to the list that will **conflict** with your first one. This is the core design principle of multi-agent systems: **value comes from structured disagreement**, not consensus.

Think about real tradeoffs in building design:
- **Daylight** wants more glass / **Energy** wants less
- **Carbon** wants compact forms / **Comfort** wants generous floor plates
- **Resilience** wants conservative design / **Cost** wants minimal material

Write it the same way — a clear role, specific angles, and boundaries. Separate agents with a comma inside the list.

---

### Step 7 — Run the Debate

1. **Save** `negotiators.py` — the dashboard detects the change automatically within a few seconds
2. Check the browser — the header should show your agents are loaded (e.g., "3 agents online" with one advocate, "4" with two)
3. Click **Quick Debate** or **Full Debate** — saving alone doesn't start a debate, you need to click the button each time
4. Watch the cards appear as each agent finishes

---

### Step 8 — Read the Results

- **Advocate cards** — each agent's argument, critical finding, and proposed changes. Did they argue what you expected?
- **Manager card** — look for:
  - **Agreements** — where did everyone align?
  - **Conflicts** — what did they fight about? What did the manager sacrifice and why?
  - **Suggested geometry** — concrete values the manager proposes
- **Apply button** — pushes the manager's geometry back into the sliders

---

### Step 9 — Iterate and Improve

- **Sharpen your prompts** — if an advocate was vague, add specific angles and numbers. Run again and compare.
- **Add a third advocate** — create a three-way tension the manager must resolve.
- **Click Apply, then re-debate** — agents now argue about the *manager's* suggested geometry. Do they change their minds?
- **Change the site** — try a desert city, a coastal city. How do the arguments shift?
- **Edit the manager** — change how it resolves conflicts. Tell it to prioritize one concern over others.

---

### What You Just Built

The system you used follows a pattern that applies far beyond this workshop:

| Concept | In this workshop | In any agent system |
|---|---|---|
| **Agent definition** | `Agent(name, role, instructions)` | System prompt sent to any LLM API |
| **Context injection** | Geometry + climate data as user message | Any structured data passed to the model |
| **Output schema** | JSON format appended to instructions | Response format specification (JSON, function calls, etc.) |
| **Orchestration** | Research → parallel advocates → manager synthesis | Sequential dependencies, parallel fan-out, aggregation |
| **Prompt quality** | Specific, opinionated, bounded instructions | The single biggest lever in any AI system |

The frameworks change — OpenAI Assistants, Anthropic Claude, LangChain, CrewAI — but the underlying pattern is always the same: define agents as structured prompts, give them context, constrain their output format, and orchestrate who runs when.

---

## Troubleshooting

| Problem | Fix |
|---|---|
| Nothing happens when I click debate | Your `advocates` list is empty. Add at least one agent to the list (see Step 5). |
| Agent count dropped to 0 after saving | You likely have a typo in `negotiators.py`. Check the backend terminal for a red error message. Common causes: missing comma between agents, unclosed quote, extra/missing parenthesis. |
| `ollama: command not found` | Restart your terminal after installing Ollama. On macOS, open the Ollama app first. |
| `ollama signin` fails | Make sure Ollama is updated to the latest version. |
| `ollama pull` hangs or fails | Check your internet connection. Try again — downloads can be interrupted and resumed. |
| `python: command not found` | On macOS/Linux, use `python3` instead of `python`. On Windows, reinstall Python and check "Add to PATH". |
| `pip: command not found` | Use `pip3` on macOS/Linux, or `python -m pip` on any platform. |
| `node: command not found` | Restart your terminal after installing Node.js. |
| `npm install` fails | Delete `frontend/node_modules` and try again. Make sure you're in the `frontend` folder. |
| verify.py says model not found | Run `ollama pull glm-5.1:cloud` and make sure `ollama signin` succeeded. |
| Browser shows blank page | Make sure the frontend dev server is running (`npm run dev` in the `frontend` folder). |
| "Connection refused" in browser | Make sure the backend is running on port 8002. |
| `pip install` fails on numpy | Run `python -m pip install --upgrade pip` first, then try again. |
| Ollama commands hang / time out | University or corporate networks may block Ollama's cloud servers. Try using a phone hotspot. |

If you're stuck, ask for help early — don't wait until the workshop starts.
