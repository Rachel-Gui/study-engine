class Agent:
    """A named agent with a role, instructions, and visual identity.

    Students create instances of this class in negotiators.py.
    The backend reads these definitions and turns them into Ollama API calls.
    """

    def __init__(self, name: str, role: str, instructions: str, color: str = "#666", icon: str = "bot"):
        self.name = name
        self.role = role
        self.instructions = instructions
        self.color = color
        self.icon = icon

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "role": self.role,
            "instructions": self.instructions,
            "color": self.color,
            "icon": self.icon,
        }
